import { 
  users, type User, type InsertUser,
  categories, type Category, type InsertCategory,
  products, type Product, type InsertProduct,
  cartItems, type CartItem, type InsertCartItem,
  wishlistItems, type WishlistItem, type InsertWishlistItem,
  orders, type Order, type InsertOrder,
  type OrderItem, type Address
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, ilike, gte, lte, inArray } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  
  // Categories
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Products
  getProducts(options?: {
    featured?: boolean;
    new?: boolean;
    trending?: boolean;
    bestSeller?: boolean;
    categoryId?: number;
    categorySlug?: string;
    limit?: number;
    search?: string;
    brands?: string[];
    minPrice?: number;
    maxPrice?: number;
    sort?: string;
  }): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  getProductBySlug(slug: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  
  // Cart
  getCartItems(userId: number): Promise<CartItem[]>;
  getCartItem(id: number): Promise<CartItem | undefined>;
  getCartItemByProductAndUser(productId: number, userId: number, size: string, color: string): Promise<CartItem | undefined>;
  createCartItem(cartItem: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: number, cartItem: Partial<CartItem>): Promise<CartItem | undefined>;
  deleteCartItem(id: number): Promise<boolean>;
  clearCart(userId: number): Promise<boolean>;
  
  // Wishlist
  getWishlistItems(userId: number): Promise<WishlistItem[]>;
  getWishlistItem(id: number): Promise<WishlistItem | undefined>;
  getWishlistItemByProductAndUser(productId: number, userId: number): Promise<WishlistItem | undefined>;
  createWishlistItem(wishlistItem: InsertWishlistItem): Promise<WishlistItem>;
  deleteWishlistItem(id: number): Promise<boolean>;
  
  // Orders
  getOrders(userId: number): Promise<Order[]>;
  getOrder(id: number): Promise<Order | undefined>;
  getOrderByOrderNumber(orderNumber: string): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: number, order: Partial<Order>): Promise<Order | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private products: Map<number, Product>;
  private cartItems: Map<number, CartItem>;
  private wishlistItems: Map<number, WishlistItem>;
  private orders: Map<number, Order>;
  
  private currentUserId: number;
  private currentCategoryId: number;
  private currentProductId: number;
  private currentCartItemId: number;
  private currentWishlistItemId: number;
  private currentOrderId: number;
  
  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.products = new Map();
    this.cartItems = new Map();
    this.wishlistItems = new Map();
    this.orders = new Map();
    
    this.currentUserId = 1;
    this.currentCategoryId = 1;
    this.currentProductId = 1;
    this.currentCartItemId = 1;
    this.currentWishlistItemId = 1;
    this.currentOrderId = 1;
    
    this.seedData();
  }
  
  private seedData() {
    // Seed Categories
    const categoriesData: InsertCategory[] = [
      {
        name: "Men's Fashion",
        slug: "mens-fashion",
        description: "Explore the latest trends in men's fashion",
        imageUrl: "https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&h=500&q=80"
      },
      {
        name: "Women's Fashion",
        slug: "womens-fashion",
        description: "Discover the latest in women's fashion",
        imageUrl: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&h=500&q=80"
      },
      {
        name: "Kids' Fashion",
        slug: "kids-fashion",
        description: "Adorable styles for the little ones",
        imageUrl: "https://images.unsplash.com/photo-1596870230751-ebdfce98ec42?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&h=500&q=80"
      },
      {
        name: "Accessories",
        slug: "accessories",
        description: "Complete your look with our trendy accessories",
        imageUrl: "https://images.unsplash.com/photo-1556906781-9a412961c28c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&h=500&q=80"
      }
    ];
    
    categoriesData.forEach(category => this.createCategory(category));
    
    // Seed Products
    const productsData: InsertProduct[] = [
      {
        name: "Floral Print Summer Dress",
        brand: "Borcelle Originals",
        description: "A beautiful floral print summer dress perfect for the warm season. Made with lightweight fabric for comfort.",
        slug: "floral-print-summer-dress",
        price: 1299,
        originalPrice: 1999,
        discount: 35,
        categoryId: 2, // Women's Fashion
        images: [
          "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=533&q=80"
        ],
        sizes: ["XS", "S", "M", "L", "XL"],
        colors: [{ name: "Pink", code: "#FF9CAD" }, { name: "White", code: "#FFFFFF" }],
        tags: ["summer", "dress", "floral"],
        isFeatured: true,
        isNew: true,
        isTrending: false,
        isBestSeller: false,
        stock: 50
      },
      {
        name: "Men's Regular Fit Casual Shirt",
        brand: "Urban Style",
        description: "A comfortable and stylish casual shirt for men. Perfect for daily wear.",
        slug: "mens-regular-fit-casual-shirt",
        price: 899,
        originalPrice: 1499,
        discount: 40,
        categoryId: 1, // Men's Fashion
        images: [
          "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=533&q=80"
        ],
        sizes: ["S", "M", "L", "XL", "XXL"],
        colors: [{ name: "Blue", code: "#3B82F6" }, { name: "Black", code: "#000000" }],
        tags: ["casual", "shirt", "men"],
        isFeatured: false,
        isNew: false,
        isTrending: true,
        isBestSeller: false,
        stock: 75
      },
      {
        name: "Men's Faux Leather Jacket",
        brand: "Roadster",
        description: "A stylish faux leather jacket for men. Perfect for a stylish and edgy look.",
        slug: "mens-faux-leather-jacket",
        price: 2499,
        originalPrice: 3999,
        discount: 38,
        categoryId: 1, // Men's Fashion
        images: [
          "https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=533&q=80"
        ],
        sizes: ["S", "M", "L", "XL"],
        colors: [{ name: "Brown", code: "#964B00" }, { name: "Black", code: "#000000" }],
        tags: ["jacket", "leather", "men"],
        isFeatured: false,
        isNew: false,
        isTrending: true,
        isBestSeller: false,
        stock: 30
      },
      {
        name: "Women's White Platform Sneakers",
        brand: "Sneaker Studio",
        description: "Comfortable and stylish platform sneakers for women. Great for casual outings.",
        slug: "womens-white-platform-sneakers",
        price: 1799,
        originalPrice: 2499,
        discount: 28,
        categoryId: 4, // Accessories
        images: [
          "https://images.unsplash.com/photo-1617922001439-4a2e6562f328?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=533&q=80"
        ],
        sizes: ["UK5", "UK6", "UK7", "UK8"],
        colors: [{ name: "White", code: "#FFFFFF" }],
        tags: ["sneakers", "platform", "women"],
        isFeatured: true,
        isNew: true,
        isTrending: false,
        isBestSeller: false,
        stock: 40
      },
      {
        name: "Men's Slim Fit Jeans",
        brand: "Levis",
        description: "Comfortable and stylish slim fit jeans for men. Perfect for a casual look.",
        slug: "mens-slim-fit-jeans",
        price: 1999,
        originalPrice: 3199,
        discount: 37,
        categoryId: 1, // Men's Fashion
        images: [
          "https://images.unsplash.com/photo-1583744946564-b52d01a7f418?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=533&q=80"
        ],
        sizes: ["30", "32", "34", "36", "38"],
        colors: [{ name: "Blue", code: "#1E3A8A" }, { name: "Black", code: "#000000" }],
        tags: ["jeans", "slim fit", "men"],
        isFeatured: false,
        isNew: false,
        isTrending: true,
        isBestSeller: false,
        stock: 60
      },
      {
        name: "Women's Analog Watch",
        brand: "Fossil",
        description: "A stylish analog watch for women. Perfect for any occasion.",
        slug: "womens-analog-watch",
        price: 6495,
        originalPrice: 9995,
        discount: 35,
        categoryId: 4, // Accessories
        images: [
          "https://images.unsplash.com/photo-1618932260643-eee4a2f652a6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=533&q=80"
        ],
        sizes: ["Standard"],
        colors: [{ name: "Gold", code: "#FFD700" }, { name: "Silver", code: "#C0C0C0" }],
        tags: ["watch", "analog", "women"],
        isFeatured: false,
        isNew: false,
        isTrending: true,
        isBestSeller: true,
        stock: 25
      },
      {
        name: "Men's Cotton Jacket",
        brand: "Jack & Jones",
        description: "A comfortable and stylish cotton jacket for men. Perfect for a casual look.",
        slug: "mens-cotton-jacket",
        price: 2199,
        originalPrice: 3499,
        discount: 37,
        categoryId: 1, // Men's Fashion
        images: [
          "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=533&q=80"
        ],
        sizes: ["S", "M", "L", "XL"],
        colors: [{ name: "Black", code: "#000000" }, { name: "Navy", code: "#000080" }],
        tags: ["jacket", "cotton", "men"],
        isFeatured: true,
        isNew: false,
        isTrending: true,
        isBestSeller: false,
        stock: 35
      },
      {
        name: "Women's Running Shoes",
        brand: "Nike",
        description: "Comfortable and stylish running shoes for women. Perfect for sports and casual wear.",
        slug: "womens-running-shoes",
        price: 4995,
        originalPrice: 6495,
        discount: 23,
        categoryId: 4, // Accessories
        images: [
          "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=533&q=80"
        ],
        sizes: ["UK5", "UK6", "UK7", "UK8"],
        colors: [{ name: "Pink", code: "#FF69B4" }, { name: "White", code: "#FFFFFF" }],
        tags: ["shoes", "running", "women"],
        isFeatured: false,
        isNew: false,
        isTrending: true,
        isBestSeller: false,
        stock: 45
      }
    ];
    
    productsData.forEach(product => this.createProduct(product));
  }
  
  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id, createdAt: new Date() };
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // Categories
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }
  
  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }
  
  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(
      (category) => category.slug === slug,
    );
  }
  
  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.currentCategoryId++;
    const category: Category = { ...insertCategory, id };
    this.categories.set(id, category);
    return category;
  }
  
  // Products
  async getProducts(options: {
    featured?: boolean;
    new?: boolean;
    trending?: boolean;
    bestSeller?: boolean;
    categoryId?: number;
    categorySlug?: string;
    limit?: number;
    search?: string;
    brands?: string[];
    minPrice?: number;
    maxPrice?: number;
    sort?: string;
  } = {}): Promise<Product[]> {
    let products = Array.from(this.products.values());
    
    if (options.featured) {
      products = products.filter(product => product.isFeatured);
    }
    
    if (options.new) {
      products = products.filter(product => product.isNew);
    }
    
    if (options.trending) {
      products = products.filter(product => product.isTrending);
    }
    
    if (options.bestSeller) {
      products = products.filter(product => product.isBestSeller);
    }
    
    if (options.categoryId) {
      products = products.filter(product => product.categoryId === options.categoryId);
    }
    
    if (options.categorySlug) {
      const category = Array.from(this.categories.values()).find(
        (category) => category.slug === options.categorySlug,
      );
      if (category) {
        products = products.filter(product => product.categoryId === category.id);
      }
    }
    
    if (options.brands && options.brands.length > 0) {
      products = products.filter(product => options.brands!.includes(product.brand));
    }
    
    if (options.minPrice !== undefined) {
      products = products.filter(product => product.price >= options.minPrice!);
    }
    
    if (options.maxPrice !== undefined) {
      products = products.filter(product => product.price <= options.maxPrice!);
    }
    
    if (options.search) {
      const search = options.search.toLowerCase();
      products = products.filter(
        product => 
          product.name.toLowerCase().includes(search) || 
          product.brand.toLowerCase().includes(search) || 
          product.description.toLowerCase().includes(search) ||
          (product.tags && product.tags.some(tag => tag.toLowerCase().includes(search)))
      );
    }
    
    if (options.sort) {
      switch (options.sort) {
        case 'price_asc':
          products = products.sort((a, b) => a.price - b.price);
          break;
        case 'price_desc':
          products = products.sort((a, b) => b.price - a.price);
          break;
        case 'discount_desc':
          products = products.sort((a, b) => b.discount - a.discount);
          break;
        case 'new':
          products = products.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
          break;
      }
    }
    
    if (options.limit) {
      products = products.slice(0, options.limit);
    }
    
    return products;
  }
  
  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }
  
  async getProductBySlug(slug: string): Promise<Product | undefined> {
    return Array.from(this.products.values()).find(
      (product) => product.slug === slug,
    );
  }
  
  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.currentProductId++;
    const product: Product = { ...insertProduct, id, createdAt: new Date() };
    this.products.set(id, product);
    return product;
  }
  
  // Cart
  async getCartItems(userId: number): Promise<CartItem[]> {
    return Array.from(this.cartItems.values()).filter(
      (cartItem) => cartItem.userId === userId,
    );
  }
  
  async getCartItem(id: number): Promise<CartItem | undefined> {
    return this.cartItems.get(id);
  }
  
  async getCartItemByProductAndUser(productId: number, userId: number, size: string, color: string): Promise<CartItem | undefined> {
    return Array.from(this.cartItems.values()).find(
      (cartItem) => 
        cartItem.productId === productId && 
        cartItem.userId === userId &&
        cartItem.size === size &&
        cartItem.color === color
    );
  }
  
  async createCartItem(insertCartItem: InsertCartItem): Promise<CartItem> {
    const id = this.currentCartItemId++;
    const cartItem: CartItem = { ...insertCartItem, id, createdAt: new Date() };
    this.cartItems.set(id, cartItem);
    return cartItem;
  }
  
  async updateCartItem(id: number, cartItemData: Partial<CartItem>): Promise<CartItem | undefined> {
    const cartItem = await this.getCartItem(id);
    if (!cartItem) return undefined;
    
    const updatedCartItem = { ...cartItem, ...cartItemData };
    this.cartItems.set(id, updatedCartItem);
    return updatedCartItem;
  }
  
  async deleteCartItem(id: number): Promise<boolean> {
    return this.cartItems.delete(id);
  }
  
  async clearCart(userId: number): Promise<boolean> {
    const cartItems = await this.getCartItems(userId);
    cartItems.forEach(item => this.cartItems.delete(item.id));
    return true;
  }
  
  // Wishlist
  async getWishlistItems(userId: number): Promise<WishlistItem[]> {
    return Array.from(this.wishlistItems.values()).filter(
      (wishlistItem) => wishlistItem.userId === userId,
    );
  }
  
  async getWishlistItem(id: number): Promise<WishlistItem | undefined> {
    return this.wishlistItems.get(id);
  }
  
  async getWishlistItemByProductAndUser(productId: number, userId: number): Promise<WishlistItem | undefined> {
    return Array.from(this.wishlistItems.values()).find(
      (wishlistItem) => wishlistItem.productId === productId && wishlistItem.userId === userId,
    );
  }
  
  async createWishlistItem(insertWishlistItem: InsertWishlistItem): Promise<WishlistItem> {
    const id = this.currentWishlistItemId++;
    const wishlistItem: WishlistItem = { ...insertWishlistItem, id, createdAt: new Date() };
    this.wishlistItems.set(id, wishlistItem);
    return wishlistItem;
  }
  
  async deleteWishlistItem(id: number): Promise<boolean> {
    return this.wishlistItems.delete(id);
  }
  
  // Orders
  async getOrders(userId: number): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(
      (order) => order.userId === userId,
    );
  }
  
  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }
  
  async getOrderByOrderNumber(orderNumber: string): Promise<Order | undefined> {
    return Array.from(this.orders.values()).find(
      (order) => order.orderNumber === orderNumber,
    );
  }
  
  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = this.currentOrderId++;
    const order: Order = { ...insertOrder, id, createdAt: new Date() };
    this.orders.set(id, order);
    return order;
  }
  
  async updateOrder(id: number, orderData: Partial<Order>): Promise<Order | undefined> {
    const order = await this.getOrder(id);
    if (!order) return undefined;
    
    const updatedOrder = { ...order, ...orderData };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }
  
  // Categories
  async getCategories(): Promise<Category[]> {
    return db.select().from(categories);
  }
  
  async getCategory(id: number): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.id, id));
    return category || undefined;
  }
  
  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.slug, slug));
    return category || undefined;
  }
  
  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const [category] = await db
      .insert(categories)
      .values(insertCategory)
      .returning();
    return category;
  }
  
  // Products
  async getProducts(options: {
    featured?: boolean;
    new?: boolean;
    trending?: boolean;
    bestSeller?: boolean;
    categoryId?: number;
    categorySlug?: string;
    limit?: number;
    search?: string;
    brands?: string[];
    minPrice?: number;
    maxPrice?: number;
    sort?: string;
  } = {}): Promise<Product[]> {
    let query = db.select().from(products);
    
    if (options.featured) {
      query = query.where(eq(products.isFeatured, true));
    }
    
    if (options.new) {
      query = query.where(eq(products.isNew, true));
    }
    
    if (options.trending) {
      query = query.where(eq(products.isTrending, true));
    }
    
    if (options.bestSeller) {
      query = query.where(eq(products.isBestSeller, true));
    }
    
    if (options.categoryId) {
      query = query.where(eq(products.categoryId, options.categoryId));
    }
    
    if (options.categorySlug) {
      const [category] = await db.select().from(categories).where(eq(categories.slug, options.categorySlug));
      if (category) {
        query = query.where(eq(products.categoryId, category.id));
      }
    }
    
    if (options.brands && options.brands.length > 0) {
      query = query.where(inArray(products.brand, options.brands));
    }
    
    if (options.minPrice !== undefined) {
      query = query.where(gte(products.price, options.minPrice));
    }
    
    if (options.maxPrice !== undefined) {
      query = query.where(lte(products.price, options.maxPrice));
    }
    
    if (options.search) {
      const search = options.search.toLowerCase();
      query = query.where(
        or(
          ilike(products.name, `%${search}%`),
          ilike(products.brand, `%${search}%`),
          ilike(products.description, `%${search}%`)
        )
      );
    }
    
    if (options.limit) {
      query = query.limit(options.limit);
    }
    
    return query;
  }
  
  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product || undefined;
  }
  
  async getProductBySlug(slug: string): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.slug, slug));
    return product || undefined;
  }
  
  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const [product] = await db
      .insert(products)
      .values(insertProduct)
      .returning();
    return product;
  }
  
  // Cart
  async getCartItems(userId: number): Promise<CartItem[]> {
    return db.select().from(cartItems).where(eq(cartItems.userId, userId));
  }
  
  async getCartItem(id: number): Promise<CartItem | undefined> {
    const [cartItem] = await db.select().from(cartItems).where(eq(cartItems.id, id));
    return cartItem || undefined;
  }
  
  async getCartItemByProductAndUser(productId: number, userId: number, size: string, color: string): Promise<CartItem | undefined> {
    const [cartItem] = await db.select().from(cartItems).where(
      and(
        eq(cartItems.productId, productId),
        eq(cartItems.userId, userId),
        eq(cartItems.size, size),
        eq(cartItems.color, color)
      )
    );
    return cartItem || undefined;
  }
  
  async createCartItem(insertCartItem: InsertCartItem): Promise<CartItem> {
    const [cartItem] = await db
      .insert(cartItems)
      .values(insertCartItem)
      .returning();
    return cartItem;
  }
  
  async updateCartItem(id: number, cartItemData: Partial<CartItem>): Promise<CartItem | undefined> {
    const [cartItem] = await db
      .update(cartItems)
      .set(cartItemData)
      .where(eq(cartItems.id, id))
      .returning();
    return cartItem || undefined;
  }
  
  async deleteCartItem(id: number): Promise<boolean> {
    const [deleted] = await db
      .delete(cartItems)
      .where(eq(cartItems.id, id))
      .returning();
    return !!deleted;
  }
  
  async clearCart(userId: number): Promise<boolean> {
    await db.delete(cartItems).where(eq(cartItems.userId, userId));
    return true;
  }
  
  // Wishlist
  async getWishlistItems(userId: number): Promise<WishlistItem[]> {
    return db.select().from(wishlistItems).where(eq(wishlistItems.userId, userId));
  }
  
  async getWishlistItem(id: number): Promise<WishlistItem | undefined> {
    const [wishlistItem] = await db.select().from(wishlistItems).where(eq(wishlistItems.id, id));
    return wishlistItem || undefined;
  }
  
  async getWishlistItemByProductAndUser(productId: number, userId: number): Promise<WishlistItem | undefined> {
    const [wishlistItem] = await db.select().from(wishlistItems).where(
      and(
        eq(wishlistItems.productId, productId),
        eq(wishlistItems.userId, userId)
      )
    );
    return wishlistItem || undefined;
  }
  
  async createWishlistItem(insertWishlistItem: InsertWishlistItem): Promise<WishlistItem> {
    const [wishlistItem] = await db
      .insert(wishlistItems)
      .values(insertWishlistItem)
      .returning();
    return wishlistItem;
  }
  
  async deleteWishlistItem(id: number): Promise<boolean> {
    const [deleted] = await db
      .delete(wishlistItems)
      .where(eq(wishlistItems.id, id))
      .returning();
    return !!deleted;
  }
  
  // Orders
  async getOrders(userId: number): Promise<Order[]> {
    return db.select().from(orders).where(eq(orders.userId, userId));
  }
  
  async getOrder(id: number): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    return order || undefined;
  }
  
  async getOrderByOrderNumber(orderNumber: string): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.orderNumber, orderNumber));
    return order || undefined;
  }
  
  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const [order] = await db
      .insert(orders)
      .values(insertOrder)
      .returning();
    return order;
  }
  
  async updateOrder(id: number, orderData: Partial<Order>): Promise<Order | undefined> {
    const [order] = await db
      .update(orders)
      .set(orderData)
      .where(eq(orders.id, id))
      .returning();
    return order || undefined;
  }
}

export const storage = new DatabaseStorage();
