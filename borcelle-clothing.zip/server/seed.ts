import { db } from './db';
import { 
  categories, type InsertCategory,
  products, type InsertProduct,
} from '@shared/schema';

async function seedDatabase() {
  console.log('Seeding database...');
  
  // Seed Categories
  const categoriesData: InsertCategory[] = [
    {
      name: "Men's Fashion",
      slug: "mens-fashion",
      description: "Explore the latest trends in men's fashion",
      imageUrl: "https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&h=500&q=80"
    },
    {
      name: "Women's Fashion",
      slug: "womens-fashion",
      description: "Discover the latest in women's fashion",
      imageUrl: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&h=500&q=80"
    },
    {
      name: "Kids' Fashion",
      slug: "kids-fashion",
      description: "Adorable styles for the little ones",
      imageUrl: "https://images.unsplash.com/photo-1596870230751-ebdfce98ec42?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&h=500&q=80"
    },
    {
      name: "Accessories",
      slug: "accessories",
      description: "Complete your look with our trendy accessories",
      imageUrl: "https://images.unsplash.com/photo-1556906781-9a412961c28c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&h=500&q=80"
    }
  ];
  
  console.log('Seeding categories...');
  
  // First check if categories already exist to avoid duplicates
  const existingCategories = await db.select().from(categories);
  if (existingCategories.length === 0) {
    for (const category of categoriesData) {
      await db.insert(categories).values({
        ...category,
        description: category.description || null,
        imageUrl: category.imageUrl || null
      });
    }
    console.log(`${categoriesData.length} categories seeded successfully`);
  } else {
    console.log('Categories already exist, skipping category seed');
  }
  
  // Seed Products
  const productsData: InsertProduct[] = [
    {
      name: "Floral Print Summer Dress",
      brand: "Borcelle Originals",
      description: "A beautiful floral print summer dress perfect for the warm season. Made with lightweight fabric for comfort.",
      slug: "floral-print-summer-dress",
      price: 1299,
      originalPrice: 1999,
      discount: 35,
      categoryId: 2, // Women's Fashion
      images: [
        "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=533&q=80"
      ],
      sizes: ["XS", "S", "M", "L", "XL"],
      colors: [{ name: "Pink", code: "#FF9CAD" }, { name: "White", code: "#FFFFFF" }],
      tags: ["summer", "dress", "floral"],
      isFeatured: true,
      isNew: true,
      isTrending: false,
      isBestSeller: false,
      stock: 50
    },
    {
      name: "Men's Regular Fit Casual Shirt",
      brand: "Urban Style",
      description: "A comfortable and stylish casual shirt for men. Perfect for daily wear.",
      slug: "mens-regular-fit-casual-shirt",
      price: 899,
      originalPrice: 1499,
      discount: 40,
      categoryId: 1, // Men's Fashion
      images: [
        "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=533&q=80"
      ],
      sizes: ["S", "M", "L", "XL", "XXL"],
      colors: [{ name: "Blue", code: "#3B82F6" }, { name: "Black", code: "#000000" }],
      tags: ["casual", "shirt", "men"],
      isFeatured: false,
      isNew: false,
      isTrending: true,
      isBestSeller: false,
      stock: 75
    },
    {
      name: "Men's Faux Leather Jacket",
      brand: "Roadster",
      description: "A stylish faux leather jacket for men. Perfect for a stylish and edgy look.",
      slug: "mens-faux-leather-jacket",
      price: 2499,
      originalPrice: 3999,
      discount: 38,
      categoryId: 1, // Men's Fashion
      images: [
        "https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=533&q=80"
      ],
      sizes: ["S", "M", "L", "XL"],
      colors: [{ name: "Brown", code: "#964B00" }, { name: "Black", code: "#000000" }],
      tags: ["jacket", "leather", "men"],
      isFeatured: false,
      isNew: false,
      isTrending: true,
      isBestSeller: false,
      stock: 30
    },
    {
      name: "Women's White Platform Sneakers",
      brand: "Sneaker Studio",
      description: "Comfortable and stylish platform sneakers for women. Great for casual outings.",
      slug: "womens-white-platform-sneakers",
      price: 1799,
      originalPrice: 2499,
      discount: 28,
      categoryId: 4, // Accessories
      images: [
        "https://images.unsplash.com/photo-1617922001439-4a2e6562f328?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=533&q=80"
      ],
      sizes: ["UK5", "UK6", "UK7", "UK8"],
      colors: [{ name: "White", code: "#FFFFFF" }],
      tags: ["sneakers", "platform", "women"],
      isFeatured: true,
      isNew: true,
      isTrending: false,
      isBestSeller: false,
      stock: 40
    },
    {
      name: "Men's Slim Fit Jeans",
      brand: "Levis",
      description: "Comfortable and stylish slim fit jeans for men. Perfect for a casual look.",
      slug: "mens-slim-fit-jeans",
      price: 1999,
      originalPrice: 3199,
      discount: 37,
      categoryId: 1, // Men's Fashion
      images: [
        "https://images.unsplash.com/photo-1583744946564-b52d01a7f418?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=533&q=80"
      ],
      sizes: ["30", "32", "34", "36", "38"],
      colors: [{ name: "Blue", code: "#1E3A8A" }, { name: "Black", code: "#000000" }],
      tags: ["jeans", "slim fit", "men"],
      isFeatured: false,
      isNew: false,
      isTrending: true,
      isBestSeller: false,
      stock: 60
    },
    {
      name: "Women's Analog Watch",
      brand: "Fossil",
      description: "A stylish analog watch for women. Perfect for any occasion.",
      slug: "womens-analog-watch",
      price: 6495,
      originalPrice: 9995,
      discount: 35,
      categoryId: 4, // Accessories
      images: [
        "https://images.unsplash.com/photo-1618932260643-eee4a2f652a6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=533&q=80"
      ],
      sizes: ["Standard"],
      colors: [{ name: "Gold", code: "#FFD700" }, { name: "Silver", code: "#C0C0C0" }],
      tags: ["watch", "analog", "women"],
      isFeatured: false,
      isNew: false,
      isTrending: true,
      isBestSeller: true,
      stock: 25
    },
    {
      name: "Men's Cotton Jacket",
      brand: "Jack & Jones",
      description: "A comfortable and stylish cotton jacket for men. Perfect for a casual look.",
      slug: "mens-cotton-jacket",
      price: 2199,
      originalPrice: 3499,
      discount: 37,
      categoryId: 1, // Men's Fashion
      images: [
        "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=533&q=80"
      ],
      sizes: ["S", "M", "L", "XL"],
      colors: [{ name: "Black", code: "#000000" }, { name: "Navy", code: "#000080" }],
      tags: ["jacket", "cotton", "men"],
      isFeatured: true,
      isNew: false,
      isTrending: true,
      isBestSeller: false,
      stock: 35
    },
    {
      name: "Women's Running Shoes",
      brand: "Nike",
      description: "Comfortable and stylish running shoes for women. Perfect for sports and casual wear.",
      slug: "womens-running-shoes",
      price: 4995,
      originalPrice: 6495,
      discount: 23,
      categoryId: 4, // Accessories
      images: [
        "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=533&q=80"
      ],
      sizes: ["UK5", "UK6", "UK7", "UK8"],
      colors: [{ name: "Pink", code: "#FF69B4" }, { name: "White", code: "#FFFFFF" }],
      tags: ["shoes", "running", "women"],
      isFeatured: false,
      isNew: false,
      isTrending: true,
      isBestSeller: false,
      stock: 45
    }
  ];
  
  console.log('Seeding products...');
  
  // First check if products already exist to avoid duplicates
  const existingProducts = await db.select().from(products);
  if (existingProducts.length === 0) {
    for (const product of productsData) {
      await db.insert(products).values({
        ...product,
        // Ensure arrays are correctly passed as arrays
        sizes: product.sizes as unknown as string[],
        colors: product.colors as unknown as { name: string; code: string }[],
        tags: product.tags as unknown as string[],
        images: product.images as unknown as string[],
      });
    }
    console.log(`${productsData.length} products seeded successfully`);
  } else {
    console.log('Products already exist, skipping product seed');
  }
  
  console.log('Database seeding completed!');
}

// In ESM modules, we can't directly check if this is the main module
// so we'll just export the seedDatabase function to be called from index.ts

export { seedDatabase };