import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertCartItemSchema, 
  insertWishlistItemSchema, 
  insertOrderSchema,
  type Product
} from "@shared/schema";
import { z } from "zod";
import Stripe from "stripe";
import { setupAuth } from "./auth";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  setupAuth(app);
  
  // API Routes
  app.get('/api/health', (_req, res) => {
    res.status(200).json({ status: 'ok' });
  });

  // Categories
  app.get('/api/categories', async (_req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching categories' });
    }
  });

  app.get('/api/categories/:slug', async (req, res) => {
    try {
      const category = await storage.getCategoryBySlug(req.params.slug);
      if (!category) {
        return res.status(404).json({ message: 'Category not found' });
      }
      res.json(category);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching category' });
    }
  });

  // Products
  app.get('/api/products', async (req, res) => {
    try {
      const { 
        featured, 
        new: isNew, 
        trending, 
        bestSeller, 
        categoryId,
        categorySlug,
        limit,
        search,
        brands,
        minPrice,
        maxPrice,
        sort
      } = req.query;
      
      const options: any = {};
      
      if (featured === 'true') options.featured = true;
      if (isNew === 'true') options.new = true;
      if (trending === 'true') options.trending = true;
      if (bestSeller === 'true') options.bestSeller = true;
      if (categoryId) options.categoryId = Number(categoryId);
      if (categorySlug) options.categorySlug = categorySlug as string;
      if (limit) options.limit = Number(limit);
      if (search) options.search = search as string;
      if (brands) options.brands = (brands as string).split(',');
      if (minPrice) options.minPrice = Number(minPrice);
      if (maxPrice) options.maxPrice = Number(maxPrice);
      if (sort) options.sort = sort as string;
      
      const products = await storage.getProducts(options);
      res.json(products);
    } catch (error) {
      console.error('Error fetching products:', error);
      res.status(500).json({ message: 'Error fetching products' });
    }
  });

  app.get('/api/products/:slug', async (req, res) => {
    try {
      const product = await storage.getProductBySlug(req.params.slug);
      if (!product) {
        return res.status(404).json({ message: 'Product not found' });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching product' });
    }
  });

  // User Auth
  app.post('/api/auth/register', async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: 'User with this email already exists' });
      }
      
      const user = await storage.createUser(userData);
      
      // Don't return password in response
      const { password, ...userWithoutPassword } = user;
      
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid request data', errors: error.errors });
      }
      res.status(500).json({ message: 'Error creating user' });
    }
  });

  app.post('/api/auth/login', async (req, res) => {
    try {
      const { email, password } = z.object({
        email: z.string().email(),
        password: z.string()
      }).parse(req.body);
      
      const user = await storage.getUserByEmail(email);
      if (!user || user.password !== password) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }
      
      // Don't return password in response
      const { password: userPassword, ...userWithoutPassword } = user;
      
      res.json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid request data', errors: error.errors });
      }
      res.status(500).json({ message: 'Error during login' });
    }
  });

  // Cart
  app.get('/api/cart', async (req, res) => {
    try {
      // In a real app, userId would come from authenticated session
      const userId = parseInt(req.query.userId as string);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: 'Invalid user ID' });
      }
      
      const cartItems = await storage.getCartItems(userId);
      
      // Fetch product details for each cart item
      const cartItemsWithDetails = await Promise.all(
        cartItems.map(async (item) => {
          const product = await storage.getProduct(item.productId);
          return {
            ...item,
            product
          };
        })
      );
      
      res.json(cartItemsWithDetails);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching cart items' });
    }
  });

  app.post('/api/cart', async (req, res) => {
    try {
      const cartItemData = insertCartItemSchema.parse(req.body);
      
      // Check if product exists
      const product = await storage.getProduct(cartItemData.productId);
      if (!product) {
        return res.status(404).json({ message: 'Product not found' });
      }
      
      // Check if this product is already in cart with same size and color
      const existingCartItem = await storage.getCartItemByProductAndUser(
        cartItemData.productId,
        cartItemData.userId,
        cartItemData.size,
        cartItemData.color
      );
      
      if (existingCartItem) {
        // Update quantity
        const updatedCartItem = await storage.updateCartItem(
          existingCartItem.id, 
          { quantity: existingCartItem.quantity + cartItemData.quantity }
        );
        
        return res.json({ ...updatedCartItem, product });
      }
      
      // Otherwise create new cart item
      const cartItem = await storage.createCartItem(cartItemData);
      
      res.status(201).json({ ...cartItem, product });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid request data', errors: error.errors });
      }
      res.status(500).json({ message: 'Error adding item to cart' });
    }
  });

  app.patch('/api/cart/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid cart item ID' });
      }
      
      const { quantity } = z.object({
        quantity: z.number().positive()
      }).parse(req.body);
      
      const cartItem = await storage.getCartItem(id);
      if (!cartItem) {
        return res.status(404).json({ message: 'Cart item not found' });
      }
      
      const updatedCartItem = await storage.updateCartItem(id, { quantity });
      const product = await storage.getProduct(cartItem.productId);
      
      res.json({ ...updatedCartItem, product });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid request data', errors: error.errors });
      }
      res.status(500).json({ message: 'Error updating cart item' });
    }
  });

  app.delete('/api/cart/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid cart item ID' });
      }
      
      const cartItem = await storage.getCartItem(id);
      if (!cartItem) {
        return res.status(404).json({ message: 'Cart item not found' });
      }
      
      await storage.deleteCartItem(id);
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Error deleting cart item' });
    }
  });

  app.delete('/api/cart', async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: 'Invalid user ID' });
      }
      
      await storage.clearCart(userId);
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Error clearing cart' });
    }
  });

  // Wishlist
  app.get('/api/wishlist', async (req, res) => {
    try {
      // In a real app, userId would come from authenticated session
      const userId = parseInt(req.query.userId as string);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: 'Invalid user ID' });
      }
      
      const wishlistItems = await storage.getWishlistItems(userId);
      
      // Fetch product details for each wishlist item
      const wishlistItemsWithDetails = await Promise.all(
        wishlistItems.map(async (item) => {
          const product = await storage.getProduct(item.productId);
          return {
            ...item,
            product
          };
        })
      );
      
      res.json(wishlistItemsWithDetails);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching wishlist items' });
    }
  });

  app.post('/api/wishlist', async (req, res) => {
    try {
      const wishlistItemData = insertWishlistItemSchema.parse(req.body);
      
      // Check if product exists
      const product = await storage.getProduct(wishlistItemData.productId);
      if (!product) {
        return res.status(404).json({ message: 'Product not found' });
      }
      
      // Check if this product is already in wishlist
      const existingWishlistItem = await storage.getWishlistItemByProductAndUser(
        wishlistItemData.productId,
        wishlistItemData.userId
      );
      
      if (existingWishlistItem) {
        return res.status(400).json({ message: 'Product already in wishlist' });
      }
      
      // Otherwise create new wishlist item
      const wishlistItem = await storage.createWishlistItem(wishlistItemData);
      
      res.status(201).json({ ...wishlistItem, product });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid request data', errors: error.errors });
      }
      res.status(500).json({ message: 'Error adding item to wishlist' });
    }
  });

  app.delete('/api/wishlist/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid wishlist item ID' });
      }
      
      const wishlistItem = await storage.getWishlistItem(id);
      if (!wishlistItem) {
        return res.status(404).json({ message: 'Wishlist item not found' });
      }
      
      await storage.deleteWishlistItem(id);
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Error deleting wishlist item' });
    }
  });

  // Orders
  app.get('/api/orders', async (req, res) => {
    try {
      // In a real app, userId would come from authenticated session
      const userId = parseInt(req.query.userId as string);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: 'Invalid user ID' });
      }
      
      const orders = await storage.getOrders(userId);
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching orders' });
    }
  });

  app.get('/api/orders/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid order ID' });
      }
      
      const order = await storage.getOrder(id);
      if (!order) {
        return res.status(404).json({ message: 'Order not found' });
      }
      
      res.json(order);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching order' });
    }
  });

  app.post('/api/orders', async (req, res) => {
    try {
      const orderData = insertOrderSchema.parse(req.body);
      
      // Generate a unique order number
      const orderNumber = `ORD-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
      
      const order = await storage.createOrder({
        ...orderData,
        orderNumber,
        status: 'pending' // Default status
      });
      
      // Clear the user's cart after successful order
      await storage.clearCart(orderData.userId);
      
      res.status(201).json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid request data', errors: error.errors });
      }
      res.status(500).json({ message: 'Error creating order' });
    }
  });

  // Stripe payment routes
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      const { amount } = req.body;
      
      if (!amount || typeof amount !== 'number') {
        return res.status(400).json({ 
          message: "Invalid request: amount is required and must be a number" 
        });
      }
      
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "usd",
        automatic_payment_methods: {
          enabled: true,
        },
      });
      
      res.json({ 
        clientSecret: paymentIntent.client_secret 
      });
    } catch (error: any) {
      console.error("Error creating payment intent:", error);
      res.status(500).json({ 
        message: "Error creating payment intent: " + error.message 
      });
    }
  });

  // Process a completed payment and create an order
  app.post('/api/process-payment', async (req, res) => {
    try {
      const { 
        paymentIntentId, 
        userId, 
        address, 
        cartItems,
        subtotal,
        tax,
        shipping
      } = req.body;
      
      if (!paymentIntentId || !userId || !address || !cartItems || !Array.isArray(cartItems)) {
        return res.status(400).json({ message: 'Invalid request data' });
      }
      
      // Verify payment was successful
      const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
      
      if (paymentIntent.status !== 'succeeded') {
        return res.status(400).json({ message: 'Payment has not been completed' });
      }
      
      // Create order items from cart
      const items = cartItems.map((item: any) => ({
        productId: item.product.id,
        name: item.product.name,
        brand: item.product.brand,
        price: item.product.price,
        originalPrice: item.product.originalPrice,
        quantity: item.quantity,
        size: item.size,
        color: item.color,
        imageUrl: item.product.images[0]
      }));
      
      // Generate a unique order number
      const orderNumber = `ORD-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
      
      // Create the order in your database
      const order = await storage.createOrder({
        userId,
        orderNumber,
        status: 'paid', // Status is paid since payment was successful
        total: subtotal + tax + shipping,
        tax,
        shipping,
        shippingAddress: address,
        items,
        paymentMethod: 'card'
      });
      
      // Clear the user's cart
      await storage.clearCart(userId);
      
      res.status(201).json(order);
    } catch (error: any) {
      console.error("Error processing payment:", error);
      res.status(500).json({ 
        message: "Error processing payment: " + error.message 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
