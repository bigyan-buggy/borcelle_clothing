import { useState, useEffect } from 'react';
import { useLocation, Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Slider } from '@/components/ui/slider';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import ProductCard from '@/components/ui/product-card';
import { ChevronRight, FilterX, SlidersHorizontal, Search, X, Loader2 } from 'lucide-react';
import { Product, Category } from '@/types';

interface ProductsPageProps {
  onQuickView: (product: Product) => void;
}

const ProductsPage = ({ onQuickView }: ProductsPageProps) => {
  const [location, setLocation] = useLocation();
  const [searchParams, setSearchParams] = useState<URLSearchParams>(
    new URLSearchParams(window.location.search)
  );
  const [showMobileFilters, setShowMobileFilters] = useState(false);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 10000]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [sortOrder, setSortOrder] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');

  const categorySlug = location.split('/').pop();
  
  // Fetching categories
  const { data: categories, isLoading: categoriesLoading } = useQuery({
    queryKey: ['/api/categories'],
    queryFn: async () => {
      const res = await fetch('/api/categories');
      if (!res.ok) throw new Error('Failed to fetch categories');
      return res.json();
    }
  });

  // Function to build query parameters
  const buildQueryParams = () => {
    const params = new URLSearchParams();
    
    if (categorySlug && categorySlug !== 'products') {
      params.set('categorySlug', categorySlug);
    }
    
    if (selectedCategory) {
      params.set('categorySlug', selectedCategory);
    }
    
    if (selectedBrands.length > 0) {
      params.set('brands', selectedBrands.join(','));
    }
    
    if (sortOrder) {
      params.set('sort', sortOrder);
    }
    
    if (searchQuery) {
      params.set('search', searchQuery);
    }
    
    // Additional filters from URL
    if (searchParams.get('new') === 'true') {
      params.set('new', 'true');
    }
    
    if (searchParams.get('trending') === 'true') {
      params.set('trending', 'true');
    }
    
    if (searchParams.get('featured') === 'true') {
      params.set('featured', 'true');
    }
    
    if (searchParams.get('bestSeller') === 'true') {
      params.set('bestSeller', 'true');
    }

    return params;
  };

  // Fetching products with filters
  const { data: products, isLoading: productsLoading } = useQuery({
    queryKey: ['/api/products', buildQueryParams().toString()],
    queryFn: async () => {
      const params = buildQueryParams();
      const url = `/api/products?${params.toString()}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error('Failed to fetch products');
      return res.json();
    },
    enabled: !categoriesLoading
  });

  // Extract category name from slug
  const getCategoryName = (slug: string | null) => {
    if (!slug || slug === 'products') return 'All Products';
    
    const category = categories?.find((cat: Category) => cat.slug === slug);
    return category ? category.name : 'All Products';
  };

  const handleBrandSelection = (brand: string, checked: boolean) => {
    setSelectedBrands(prev => 
      checked 
        ? [...prev, brand] 
        : prev.filter(b => b !== brand)
    );
  };

  // Apply filters
  const applyFilters = () => {
    setShowMobileFilters(false);
    // Filters are applied automatically through useQuery dependencies
  };

  // Reset filters
  const resetFilters = () => {
    setSelectedCategory(null);
    setSelectedBrands([]);
    setSortOrder('');
    setPriceRange([0, 10000]);
    setSearchQuery('');
    setLocation('/products');
  };

  // Initialize filters from URL params on component mount
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setSearchParams(params);
    
    const searchFromURL = params.get('search');
    if (searchFromURL) {
      setSearchQuery(searchFromURL);
    }
    
    if (categorySlug && categorySlug !== 'products') {
      setSelectedCategory(categorySlug);
    }
    
    const brandsFromURL = params.get('brands');
    if (brandsFromURL) {
      setSelectedBrands(brandsFromURL.split(','));
    }
    
    const sortFromURL = params.get('sort');
    if (sortFromURL) {
      setSortOrder(sortFromURL);
    }
  }, [location, categorySlug]);

  // Get unique brands from products
  const uniqueBrands = () => {
    if (!products) return [];
    
    const brands = products.map((product: Product) => product.brand);
    return Array.from(new Set(brands));
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Breadcrumb */}
      <div className="flex items-center text-sm mb-8">
        <div 
          className="text-[#696B79] hover:text-[#FF3F6C] cursor-pointer"
          onClick={() => navigate("/")}
        >
          Home
        </div>
        <ChevronRight className="h-4 w-4 mx-2 text-[#696B79]" />
        <span className="font-medium">{getCategoryName(categorySlug)}</span>
      </div>

      <div className="flex flex-col lg:flex-row">
        {/* Mobile filter button */}
        <div className="lg:hidden flex justify-between items-center mb-4">
          <h1 className="text-2xl font-bold">
            {getCategoryName(categorySlug)}
            {productsLoading ? null : (
              <span className="text-[#696B79] text-base font-normal ml-2">
                ({products?.length || 0} items)
              </span>
            )}
          </h1>
          <Button 
            variant="outline" 
            className="flex items-center"
            onClick={() => setShowMobileFilters(true)}
          >
            <SlidersHorizontal className="h-4 w-4 mr-2" />
            Filter
          </Button>
        </div>

        {/* Mobile Filters Panel */}
        {showMobileFilters && (
          <div className="fixed inset-0 bg-white z-50 overflow-auto lg:hidden">
            <div className="flex items-center justify-between p-4 border-b">
              <h2 className="text-lg font-semibold">Filters</h2>
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setShowMobileFilters(false)}
              >
                <X className="h-5 w-5" />
              </Button>
            </div>
            
            <div className="p-4">
              <div className="mb-6">
                <div className="font-medium mb-3">Categories</div>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <Checkbox 
                      id="all-products-mobile" 
                      checked={!selectedCategory}
                      onCheckedChange={() => setSelectedCategory(null)}
                    />
                    <Label htmlFor="all-products-mobile" className="ml-2">All Products</Label>
                  </div>
                  
                  {categoriesLoading ? (
                    Array(4).fill(0).map((_, index) => (
                      <Skeleton key={index} className="h-6 w-24" />
                    ))
                  ) : (
                    categories?.map((category: Category) => (
                      <div key={category.id} className="flex items-center">
                        <Checkbox 
                          id={`category-${category.id}-mobile`}
                          checked={selectedCategory === category.slug}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedCategory(category.slug);
                            } else if (selectedCategory === category.slug) {
                              setSelectedCategory(null);
                            }
                          }}
                        />
                        <Label htmlFor={`category-${category.id}-mobile`} className="ml-2">{category.name}</Label>
                      </div>
                    ))
                  )}
                </div>
              </div>
              
              <Separator className="my-4" />
              
              <div className="mb-6">
                <div className="font-medium mb-3">Brands</div>
                <div className="space-y-2">
                  {productsLoading ? (
                    Array(4).fill(0).map((_, index) => (
                      <Skeleton key={index} className="h-6 w-32" />
                    ))
                  ) : (
                    uniqueBrands().map((brand, index) => (
                      <div key={index} className="flex items-center">
                        <Checkbox 
                          id={`brand-${index}-mobile`}
                          checked={selectedBrands.includes(brand)}
                          onCheckedChange={(checked) => {
                            handleBrandSelection(brand, !!checked);
                          }}
                        />
                        <Label htmlFor={`brand-${index}-mobile`} className="ml-2">{brand}</Label>
                      </div>
                    ))
                  )}
                </div>
              </div>
              
              <Separator className="my-4" />
              
              <div className="mb-6">
                <div className="font-medium mb-3">Price Range</div>
                <div className="px-2">
                  <Slider 
                    defaultValue={[0, 10000]} 
                    max={10000} 
                    step={500}
                    value={priceRange}
                    onValueChange={(values) => setPriceRange(values as [number, number])}
                  />
                  <div className="flex justify-between mt-2 text-sm">
                    <span>₹{priceRange[0]}</span>
                    <span>₹{priceRange[1]}</span>
                  </div>
                </div>
              </div>
              
              <Separator className="my-4" />
              
              <div className="mb-6">
                <div className="font-medium mb-3">Sort By</div>
                <RadioGroup value={sortOrder} onValueChange={setSortOrder}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="price_asc" id="price_asc_mobile" />
                    <Label htmlFor="price_asc_mobile">Price: Low to High</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="price_desc" id="price_desc_mobile" />
                    <Label htmlFor="price_desc_mobile">Price: High to Low</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="discount_desc" id="discount_desc_mobile" />
                    <Label htmlFor="discount_desc_mobile">Discount</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="new" id="new_mobile" />
                    <Label htmlFor="new_mobile">What's New</Label>
                  </div>
                </RadioGroup>
              </div>
              
              <div className="flex space-x-4">
                <Button 
                  className="flex-1 bg-[#FF3F6C] hover:bg-[#FF3F6C]/90"
                  onClick={applyFilters}
                >
                  Apply
                </Button>
                <Button 
                  variant="outline" 
                  className="flex-1"
                  onClick={resetFilters}
                >
                  Reset
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Desktop Filters Sidebar */}
        <div className="hidden lg:block w-64 flex-shrink-0 mr-6">
          <div className="sticky top-24">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Filters</h2>
              <Button 
                variant="ghost" 
                size="sm" 
                className="flex items-center h-8 text-sm text-[#FF3F6C]"
                onClick={resetFilters}
              >
                <FilterX className="h-4 w-4 mr-1" />
                Clear All
              </Button>
            </div>
            
            <Accordion type="multiple" defaultValue={['categories', 'brands', 'price', 'sort']}>
              <AccordionItem value="categories">
                <AccordionTrigger className="text-base font-medium">Categories</AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <Checkbox 
                        id="all-products" 
                        checked={!selectedCategory}
                        onCheckedChange={() => setSelectedCategory(null)}
                      />
                      <Label htmlFor="all-products" className="ml-2">All Products</Label>
                    </div>
                    
                    {categoriesLoading ? (
                      Array(4).fill(0).map((_, index) => (
                        <Skeleton key={index} className="h-6 w-24" />
                      ))
                    ) : (
                      categories?.map((category: Category) => (
                        <div key={category.id} className="flex items-center">
                          <Checkbox 
                            id={`category-${category.id}`}
                            checked={selectedCategory === category.slug}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                setSelectedCategory(category.slug);
                              } else if (selectedCategory === category.slug) {
                                setSelectedCategory(null);
                              }
                            }}
                          />
                          <Label htmlFor={`category-${category.id}`} className="ml-2">{category.name}</Label>
                        </div>
                      ))
                    )}
                  </div>
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="brands">
                <AccordionTrigger className="text-base font-medium">Brands</AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-2">
                    {productsLoading ? (
                      Array(4).fill(0).map((_, index) => (
                        <Skeleton key={index} className="h-6 w-32" />
                      ))
                    ) : (
                      uniqueBrands().map((brand, index) => (
                        <div key={index} className="flex items-center">
                          <Checkbox 
                            id={`brand-${index}`}
                            checked={selectedBrands.includes(brand)}
                            onCheckedChange={(checked) => {
                              handleBrandSelection(brand, !!checked);
                            }}
                          />
                          <Label htmlFor={`brand-${index}`} className="ml-2">{brand}</Label>
                        </div>
                      ))
                    )}
                  </div>
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="price">
                <AccordionTrigger className="text-base font-medium">Price Range</AccordionTrigger>
                <AccordionContent>
                  <div className="px-2">
                    <Slider 
                      defaultValue={[0, 10000]} 
                      max={10000} 
                      step={500}
                      value={priceRange}
                      onValueChange={(values) => setPriceRange(values as [number, number])}
                    />
                    <div className="flex justify-between mt-2 text-sm">
                      <span>₹{priceRange[0]}</span>
                      <span>₹{priceRange[1]}</span>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="sort">
                <AccordionTrigger className="text-base font-medium">Sort By</AccordionTrigger>
                <AccordionContent>
                  <RadioGroup value={sortOrder} onValueChange={setSortOrder}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="price_asc" id="price_asc" />
                      <Label htmlFor="price_asc">Price: Low to High</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="price_desc" id="price_desc" />
                      <Label htmlFor="price_desc">Price: High to Low</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="discount_desc" id="discount_desc" />
                      <Label htmlFor="discount_desc">Discount</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="new" id="new" />
                      <Label htmlFor="new">What's New</Label>
                    </div>
                  </RadioGroup>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>

        {/* Products */}
        <div className="flex-1">
          <div className="hidden lg:flex items-center justify-between mb-6">
            <h1 className="text-2xl font-bold">
              {getCategoryName(categorySlug)}
              {productsLoading ? null : (
                <span className="text-[#696B79] text-base font-normal ml-2">
                  ({products?.length || 0} items)
                </span>
              )}
            </h1>
            
            <div className="flex items-center">
              <div className="relative mr-4">
                <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-[#696B79]" />
                <input 
                  type="text" 
                  placeholder="Search within results" 
                  className="pl-10 pr-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-1 focus:ring-[#FF3F6C] text-sm"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              
              <Select value={sortOrder} onValueChange={setSortOrder}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="price_asc">Price: Low to High</SelectItem>
                  <SelectItem value="price_desc">Price: High to Low</SelectItem>
                  <SelectItem value="discount_desc">Discount</SelectItem>
                  <SelectItem value="new">What's New</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Products Grid */}
          {productsLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
              {Array(8).fill(0).map((_, index) => (
                <div key={index}>
                  <Skeleton className="w-full aspect-[3/4] rounded-md mb-3" />
                  <Skeleton className="h-4 w-20 mb-2" />
                  <Skeleton className="h-4 w-32 mb-2" />
                  <Skeleton className="h-4 w-24" />
                </div>
              ))}
            </div>
          ) : products?.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
              {products.map((product: Product) => (
                <ProductCard 
                  key={product.id} 
                  product={product} 
                  onQuickView={onQuickView}
                />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-64 text-center">
              <div className="text-gray-400 text-6xl mb-4">
                <i className="fas fa-search"></i>
              </div>
              <p className="text-lg font-medium mb-2">No products found</p>
              <p className="text-sm text-gray-500 mb-6">Try adjusting your filters or search criteria</p>
              <Button 
                onClick={resetFilters}
                className="bg-[#FF3F6C] hover:bg-[#FF3F6C]/90 text-white"
              >
                Clear Filters
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductsPage;
