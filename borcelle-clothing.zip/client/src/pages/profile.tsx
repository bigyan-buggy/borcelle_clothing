import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useAuth } from '@/hooks/use-auth';
import { 
  MapPin, 
  ShoppingBag, 
  Heart, 
  User, 
  CreditCard, 
  LogOut, 
  Package, 
  Settings,
  ChevronRight,
  Edit,
  Calendar,
  Clock,
  Trash2,
  Plus
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const ProfilePage = () => {
  const [_, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState('profile');
  const { user: authUser, isLoading: authLoading, logoutMutation } = useAuth();
  
  // Use authenticated user's ID
  const userId = authUser?.id;

  // Use authenticated user data directly
  const userData = authUser ? {
    ...authUser,
    phoneNumber: authUser.phoneNumber || "",  // Use phoneNumber from the user data
    // Default empty addresses array if none exists
    addresses: authUser.addresses || []
  } : null;
  
  const isLoading = authLoading;
  const user = userData;

  // Fetch orders data
  const { data: orders, isLoading: ordersLoading } = useQuery({
    queryKey: ['/api/orders', userId],
    queryFn: async () => {
      // Mock response for demo
      return [
        {
          id: 1,
          orderNumber: 'ORD-12345678',
          createdAt: '2023-06-15T10:30:00Z',
          status: 'delivered',
          total: 3299,
          items: [
            {
              productId: 1,
              name: 'Men\'s Slim Fit Jeans',
              brand: 'Levis',
              price: 1999,
              originalPrice: 3199,
              quantity: 1,
              size: '32',
              color: 'Blue',
              imageUrl: 'https://images.unsplash.com/photo-1583744946564-b52d01a7f418?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=533&q=80'
            },
            {
              productId: 4,
              name: 'Women\'s White Platform Sneakers',
              brand: 'Sneaker Studio',
              price: 1300,
              originalPrice: 1799,
              quantity: 1,
              size: 'UK7',
              color: 'White',
              imageUrl: 'https://images.unsplash.com/photo-1617922001439-4a2e6562f328?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=533&q=80'
            }
          ]
        },
        {
          id: 2,
          orderNumber: 'ORD-87654321',
          createdAt: '2023-05-20T14:15:00Z',
          status: 'delivered',
          total: 1299,
          items: [
            {
              productId: 1,
              name: 'Floral Print Summer Dress',
              brand: 'Borcelle Originals',
              price: 1299,
              originalPrice: 1999,
              quantity: 1,
              size: 'M',
              color: 'Pink',
              imageUrl: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=533&q=80'
            }
          ]
        }
      ];
    }
  });

  // Date formatter
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', { 
      day: 'numeric', 
      month: 'short', 
      year: 'numeric' 
    });
  };

  // Status badge color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'delivered':
        return 'bg-green-100 text-green-800';
      case 'shipped':
        return 'bg-blue-100 text-blue-800';
      case 'processing':
        return 'bg-amber-100 text-amber-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center p-8">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#FF3F6C]"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Left Sidebar */}
        <div className="md:w-1/4">
          <Card>
            <CardHeader>
              <div className="flex items-center">
                <Avatar className="h-16 w-16 mr-4">
                  <AvatarImage src="" alt={user?.name} />
                  <AvatarFallback className="bg-[#FF3F6C] text-white text-lg">
                    {user?.name?.split(' ').map((n: string) => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle>{user?.name}</CardTitle>
                  <CardDescription>{user?.email}</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <nav className="space-y-1">
                <Button 
                  variant="ghost" 
                  className={`w-full justify-start ${activeTab === 'profile' ? 'bg-[#FF3F6C]/10 text-[#FF3F6C]' : ''}`}
                  onClick={() => setActiveTab('profile')}
                >
                  <User className="mr-2 h-4 w-4" />
                  Account
                </Button>
                <Button 
                  variant="ghost" 
                  className={`w-full justify-start ${activeTab === 'orders' ? 'bg-[#FF3F6C]/10 text-[#FF3F6C]' : ''}`}
                  onClick={() => setActiveTab('orders')}
                >
                  <ShoppingBag className="mr-2 h-4 w-4" />
                  Orders
                </Button>
                <Button 
                  variant="ghost" 
                  className={`w-full justify-start ${activeTab === 'addresses' ? 'bg-[#FF3F6C]/10 text-[#FF3F6C]' : ''}`}
                  onClick={() => setActiveTab('addresses')}
                >
                  <MapPin className="mr-2 h-4 w-4" />
                  Addresses
                </Button>
                <Link href="/wishlist">
                  <Button variant="ghost" className="w-full justify-start">
                    <Heart className="mr-2 h-4 w-4" />
                    Wishlist
                  </Button>
                </Link>
                <Button variant="ghost" className="w-full justify-start">
                  <CreditCard className="mr-2 h-4 w-4" />
                  Saved Cards
                </Button>
                <Separator className="my-2" />
                <Button variant="ghost" className="w-full justify-start">
                  <Settings className="mr-2 h-4 w-4" />
                  Settings
                </Button>
                <Button 
                  variant="ghost" 
                  className="w-full justify-start text-red-500"
                  onClick={() => {
                    // Use the logout mutation from useAuth
                    logoutMutation.mutate();
                    navigate('/');
                  }}
                  disabled={logoutMutation.isPending}
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  {logoutMutation.isPending ? "Logging out..." : "Logout"}
                </Button>
              </nav>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="md:w-3/4">
          {activeTab === 'profile' && (
            <Card>
              <CardHeader>
                <CardTitle>Account Information</CardTitle>
                <CardDescription>Manage your personal information and preferences</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="personal" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="personal">Personal Information</TabsTrigger>
                    <TabsTrigger value="preferences">Preferences</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="personal" className="p-4 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="full-name">Full Name</Label>
                        <div className="flex mt-1">
                          <Input id="full-name" value={user?.name} readOnly className="flex-1" />
                          <Button variant="ghost" size="icon" className="ml-2">
                            <Edit size={16} />
                          </Button>
                        </div>
                      </div>
                      
                      <div>
                        <Label htmlFor="email">Email Address</Label>
                        <div className="flex mt-1">
                          <Input id="email" value={user?.email} readOnly className="flex-1" />
                          <Button variant="ghost" size="icon" className="ml-2">
                            <Edit size={16} />
                          </Button>
                        </div>
                      </div>
                      
                      <div>
                        <Label htmlFor="phone">Mobile Number</Label>
                        <div className="flex mt-1">
                          <Input id="phone" value={user?.phoneNumber} readOnly className="flex-1" />
                          <Button variant="ghost" size="icon" className="ml-2">
                            <Edit size={16} />
                          </Button>
                        </div>
                      </div>
                      
                      <div>
                        <Label htmlFor="gender">Gender</Label>
                        <div className="flex mt-1">
                          <Input id="gender" value="Male" readOnly className="flex-1" />
                          <Button variant="ghost" size="icon" className="ml-2">
                            <Edit size={16} />
                          </Button>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-6">
                      <h3 className="font-medium mb-4">Account Security</h3>
                      <Button variant="outline" className="mr-4">
                        Change Password
                      </Button>
                      <Button variant="outline">
                        Enable Two-Factor Authentication
                      </Button>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="preferences" className="p-4 space-y-4">
                    <div>
                      <h3 className="font-medium mb-4">Notification Preferences</h3>
                      <div className="space-y-2">
                        <div className="flex items-center">
                          <input 
                            type="checkbox" 
                            id="email-updates" 
                            className="h-4 w-4 rounded border-gray-300 text-[#FF3F6C] focus:ring-[#FF3F6C]" 
                            defaultChecked 
                          />
                          <Label htmlFor="email-updates" className="ml-2">
                            Email updates about new arrivals and offers
                          </Label>
                        </div>
                        <div className="flex items-center">
                          <input 
                            type="checkbox" 
                            id="sms-updates" 
                            className="h-4 w-4 rounded border-gray-300 text-[#FF3F6C] focus:ring-[#FF3F6C]" 
                            defaultChecked 
                          />
                          <Label htmlFor="sms-updates" className="ml-2">
                            SMS updates about your orders
                          </Label>
                        </div>
                        <div className="flex items-center">
                          <input 
                            type="checkbox" 
                            id="whatsapp-updates" 
                            className="h-4 w-4 rounded border-gray-300 text-[#FF3F6C] focus:ring-[#FF3F6C]" 
                          />
                          <Label htmlFor="whatsapp-updates" className="ml-2">
                            WhatsApp updates about sales and new collections
                          </Label>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-6">
                      <h3 className="font-medium mb-4">Communication Preferences</h3>
                      <div className="space-y-2">
                        <div className="flex items-center">
                          <input 
                            type="checkbox" 
                            id="newsletter" 
                            className="h-4 w-4 rounded border-gray-300 text-[#FF3F6C] focus:ring-[#FF3F6C]" 
                            defaultChecked 
                          />
                          <Label htmlFor="newsletter" className="ml-2">
                            Subscribe to newsletter
                          </Label>
                        </div>
                        <div className="flex items-center">
                          <input 
                            type="checkbox" 
                            id="promotional" 
                            className="h-4 w-4 rounded border-gray-300 text-[#FF3F6C] focus:ring-[#FF3F6C]" 
                            defaultChecked 
                          />
                          <Label htmlFor="promotional" className="ml-2">
                            Receive promotional emails
                          </Label>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-6">
                      <Button className="bg-[#FF3F6C] hover:bg-[#FF3F6C]/90 text-white">
                        Save Preferences
                      </Button>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          )}

          {activeTab === 'orders' && (
            <Card>
              <CardHeader>
                <CardTitle>My Orders</CardTitle>
                <CardDescription>Track and manage your orders</CardDescription>
              </CardHeader>
              <CardContent>
                {ordersLoading ? (
                  <div className="flex justify-center p-8">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#FF3F6C]"></div>
                  </div>
                ) : orders && orders.length > 0 ? (
                  <div className="space-y-6">
                    {orders.map((order: any) => (
                      <div key={order.id} className="border rounded-lg overflow-hidden">
                        <div className="bg-gray-50 p-4 flex flex-wrap justify-between items-center">
                          <div>
                            <p className="text-sm text-[#696B79]">Order #{order.orderNumber}</p>
                            <div className="flex items-center mt-1">
                              <Calendar className="h-4 w-4 text-[#696B79] mr-1" />
                              <span className="text-sm">{formatDate(order.createdAt)}</span>
                            </div>
                          </div>
                          <div className="flex items-center">
                            <span className={`text-xs px-2 py-1 rounded ${getStatusColor(order.status)}`}>
                              {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                            </span>
                            <Button variant="ghost" size="sm" className="ml-2">
                              View Details <ChevronRight size={16} className="ml-1" />
                            </Button>
                          </div>
                        </div>
                        
                        <div className="p-4">
                          {order.items.map((item: any, index: number) => (
                            <div key={index} className="flex py-3 border-b last:border-b-0">
                              <div className="w-16 h-20 bg-gray-100 rounded overflow-hidden">
                                <img 
                                  src={item.imageUrl} 
                                  alt={item.name} 
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div className="ml-3 flex-1">
                                <p className="text-sm font-medium">{item.brand}</p>
                                <p className="text-xs text-[#696B79]">{item.name}</p>
                                <div className="flex items-center mt-1 text-xs text-[#696B79]">
                                  <span>Size: {item.size}</span>
                                  <span className="mx-2">|</span>
                                  <span>Qty: {item.quantity}</span>
                                </div>
                                <div className="flex items-center mt-1">
                                  <span className="text-sm font-semibold">₹{item.price.toLocaleString('en-IN')}</span>
                                </div>
                              </div>
                            </div>
                          ))}
                          
                          <div className="mt-4 flex justify-between items-center">
                            <div className="font-medium">
                              Total: ₹{order.total.toLocaleString('en-IN')}
                            </div>
                            <div className="flex space-x-2">
                              <Button variant="outline" size="sm">
                                Need Help?
                              </Button>
                              {order.status === 'delivered' && (
                                <Button variant="outline" size="sm">
                                  Write Review
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Package className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-2">No orders yet</h3>
                    <p className="text-[#696B79] mb-6">
                      You haven't placed any orders yet. Start shopping and your orders will appear here.
                    </p>
                    <Link href="/products">
                      <Button className="bg-[#FF3F6C] hover:bg-[#FF3F6C]/90 text-white">
                        Start Shopping
                      </Button>
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {activeTab === 'addresses' && (
            <Card>
              <CardHeader>
                <CardTitle>Saved Addresses</CardTitle>
                <CardDescription>Manage your delivery addresses</CardDescription>
              </CardHeader>
              <CardContent>
                {user?.addresses && user.addresses.length > 0 ? (
                  <div className="space-y-4">
                    {user.addresses.map((address: any) => (
                      <div 
                        key={address.id}
                        className="border rounded-md p-4 relative"
                      >
                        <div className="absolute top-4 right-4 flex space-x-2">
                          <Button variant="ghost" size="sm" className="h-8 px-2">
                            <Edit size={16} className="mr-1" /> Edit
                          </Button>
                          <Button variant="ghost" size="sm" className="h-8 px-2 text-red-500">
                            <Trash2 size={16} className="mr-1" /> Delete
                          </Button>
                        </div>
                        
                        <div className="flex items-center mb-2">
                          <span className="font-medium mr-2">{address.name}</span>
                          {address.isDefault && (
                            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                              Default
                            </Badge>
                          )}
                        </div>
                        
                        <div className="text-sm text-[#696B79] mb-6 pr-20">
                          <p>{address.address}</p>
                          <p>{address.city}, {address.state} - {address.pincode}</p>
                          <p className="mt-1">Phone: {address.phoneNumber}</p>
                        </div>
                        
                        {!address.isDefault && (
                          <Button variant="outline" size="sm" className="text-[#FF3F6C]">
                            Set as Default
                          </Button>
                        )}
                      </div>
                    ))}
                    
                    <Button className="w-full border-dashed border-2 hover:border-[#FF3F6C] bg-transparent hover:bg-[#FF3F6C]/5 text-[#696B79] hover:text-[#FF3F6C]">
                      <Plus size={18} className="mr-2" /> Add New Address
                    </Button>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <MapPin className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-2">No addresses saved</h3>
                    <p className="text-[#696B79] mb-6">
                      You haven't saved any delivery addresses yet.
                    </p>
                    <Button className="bg-[#FF3F6C] hover:bg-[#FF3F6C]/90 text-white">
                      <Plus size={18} className="mr-2" /> Add New Address
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
