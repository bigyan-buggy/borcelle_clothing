import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Skeleton } from '@/components/ui/skeleton';
import ProductDetail from '@/components/product/ProductDetail';
import { Product } from '@/types';

interface ProductDetailPageProps {
  onQuickView: (product: Product) => void;
  onSizeGuideClick: () => void;
}

const ProductDetailPage = ({ onQuickView, onSizeGuideClick }: ProductDetailPageProps) => {
  const [location] = useLocation();
  const [slug, setSlug] = useState<string>('');

  useEffect(() => {
    const segments = location.split('/');
    if (segments.length > 2) {
      setSlug(segments[segments.length - 1]);
    }
  }, [location]);
  
  const { data: product, isLoading, error } = useQuery({
    queryKey: ['/api/products', slug],
    queryFn: async () => {
      if (!slug) return null;
      const res = await fetch(`/api/products/${slug}`);
      if (!res.ok) throw new Error('Failed to fetch product details');
      return res.json();
    },
    enabled: !!slug
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row -mx-4">
          <div className="lg:w-1/2 px-4 mb-8 lg:mb-0">
            <Skeleton className="w-full aspect-[3/4] rounded-lg" />
          </div>
          <div className="lg:w-1/2 px-4">
            <Skeleton className="h-8 w-48 mb-4" />
            <Skeleton className="h-6 w-64 mb-8" />
            <Skeleton className="h-12 w-36 mb-4" />
            <Skeleton className="h-20 w-full mb-8" />
            <Skeleton className="h-6 w-32 mb-4" />
            <Skeleton className="h-12 w-full mb-4" />
            <Skeleton className="h-6 w-32 mb-4" />
            <Skeleton className="h-12 w-full mb-8" />
            <div className="flex space-x-4 mb-8">
              <Skeleton className="h-12 flex-1" />
              <Skeleton className="h-12 w-24" />
            </div>
            <Skeleton className="h-12 w-full mb-8" />
          </div>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <div className="text-[#FF3F6C] text-6xl mb-4">
          <i className="fas fa-exclamation-circle"></i>
        </div>
        <h1 className="text-2xl font-bold mb-2">Product Not Found</h1>
        <p className="text-[#696B79] mb-8">
          We couldn't find the product you were looking for. It might have been removed or is temporarily unavailable.
        </p>
        <a 
          href="/products" 
          className="inline-block bg-[#FF3F6C] hover:bg-[#FF3F6C]/90 text-white py-3 px-6 rounded font-medium transition-colors"
        >
          Continue Shopping
        </a>
      </div>
    );
  }

  return (
    <ProductDetail 
      product={product} 
      onSizeGuideClick={onSizeGuideClick}
      onQuickView={onQuickView}
    />
  );
};

export default ProductDetailPage;
