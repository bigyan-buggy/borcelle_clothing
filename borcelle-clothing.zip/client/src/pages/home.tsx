import { useState } from 'react';
import HeroSection from '@/components/home/HeroSection';
import FeaturedCategories from '@/components/home/FeaturedCategories';
import NewArrivals from '@/components/home/NewArrivals';
import DealsSection from '@/components/home/DealsSection';
import TrendingSection from '@/components/home/TrendingSection';
import BrandsSection from '@/components/home/BrandsSection';
import TestimonialsSection from '@/components/home/TestimonialsSection';
import FeaturesSection from '@/components/home/FeaturesSection';
import AppPromotion from '@/components/home/AppPromotion';
import { Product } from '@/types';

interface HomePageProps {
  onQuickView?: (product: Product) => void;
}

const HomePage = ({ onQuickView }: HomePageProps) => {
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);

  const handleQuickView = (product: Product) => {
    setQuickViewProduct(product);
    if (onQuickView) {
      onQuickView(product);
    }
  };

  return (
    <>
      <HeroSection />
      <FeaturedCategories />
      <NewArrivals onQuickView={handleQuickView} />
      <DealsSection />
      <TrendingSection onQuickView={handleQuickView} />
      <BrandsSection />
      <TestimonialsSection />
      <FeaturesSection />
      <AppPromotion />
    </>
  );
};

export default HomePage;
