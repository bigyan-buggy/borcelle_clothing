import { useState } from 'react';
import { Link } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { ShoppingBag, Trash2, Heart } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Product } from '@/types';

const WishlistPage = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Default userId for demo purposes - in a real app this would come from authentication
  const userId = 1;

  // Fetch wishlist items
  const { data: wishlistItems = [], isLoading } = useQuery({
    queryKey: ['/api/wishlist', userId],
    queryFn: async () => {
      const res = await fetch(`/api/wishlist?userId=${userId}`);
      if (!res.ok) throw new Error('Failed to fetch wishlist items');
      return res.json();
    }
  });

  // Remove from wishlist mutation
  const removeFromWishlistMutation = useMutation({
    mutationFn: async (wishlistItemId: number) => {
      return apiRequest('DELETE', `/api/wishlist/${wishlistItemId}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/wishlist'] });
      toast({
        title: "Item removed",
        description: "Item has been removed from your wishlist",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to remove item. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Move to bag mutation
  const moveToBagMutation = useMutation({
    mutationFn: async ({ product, wishlistItemId }: { product: Product; wishlistItemId: number }) => {
      // First add to cart
      await apiRequest('POST', '/api/cart', {
        userId,
        productId: product.id,
        size: product.sizes[0], // Default to first size
        color: product.colors[0].name, // Default to first color
        quantity: 1
      });
      
      // Then remove from wishlist
      return apiRequest('DELETE', `/api/wishlist/${wishlistItemId}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/wishlist'] });
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      toast({
        title: "Moved to bag",
        description: "Item has been moved to your shopping bag",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to move item to bag. Please try again.",
        variant: "destructive",
      });
    }
  });

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-8">My Wishlist</h1>

      {isLoading ? (
        <div className="flex justify-center p-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#FF3F6C]"></div>
        </div>
      ) : wishlistItems.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <div className="flex justify-center mb-4">
            <Heart size={64} className="text-gray-300" />
          </div>
          <h2 className="text-xl font-semibold mb-2">Your wishlist is empty</h2>
          <p className="text-[#696B79] mb-6">
            Save items that you like in your wishlist.
            Review them anytime and easily move them to the bag.
          </p>
          <Link href="/products">
            <Button className="bg-[#FF3F6C] hover:bg-[#FF3F6C]/90 text-white">
              Continue Shopping
            </Button>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {wishlistItems.map((item: any) => (
            <div key={item.id} className="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-200 group">
              <Link href={`/product/${item.product.slug}`}>
                <a className="block">
                  <div className="relative h-64 overflow-hidden">
                    <img 
                      src={item.product.images[0]} 
                      alt={item.product.name} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-2 right-2">
                      <button 
                        className="w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-sm hover:bg-gray-100"
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          removeFromWishlistMutation.mutate(item.id);
                        }}
                        aria-label="Remove from wishlist"
                      >
                        <Trash2 size={16} className="text-[#FF3F6C]" />
                      </button>
                    </div>
                  </div>
                </a>
              </Link>
              
              <div className="p-4">
                <h3 className="font-medium text-[#3E4152] truncate">{item.product.brand}</h3>
                <p className="text-sm text-[#696B79] truncate">{item.product.name}</p>
                <div className="flex items-center mt-1">
                  <span className="font-semibold mr-2">₹{item.product.price.toLocaleString('en-IN')}</span>
                  <span className="text-sm text-gray-500 line-through mr-2">₹{item.product.originalPrice.toLocaleString('en-IN')}</span>
                  <span className="text-xs text-[#14CDA2] font-medium">{item.product.discount}% OFF</span>
                </div>
                
                <Button 
                  className="w-full mt-4 bg-[#FF3F6C] hover:bg-[#FF3F6C]/90 text-white"
                  onClick={() => moveToBagMutation.mutate({ 
                    product: item.product, 
                    wishlistItemId: item.id 
                  })}
                  disabled={moveToBagMutation.isPending}
                >
                  <ShoppingBag size={16} className="mr-2" />
                  {moveToBagMutation.isPending ? 'Moving...' : 'Move to Bag'}
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default WishlistPage;
