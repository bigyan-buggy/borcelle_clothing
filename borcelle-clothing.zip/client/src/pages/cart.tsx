import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { ShoppingBag, Truck, Heart, Trash2, Plus, Minus, ArrowRight } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { formatPrice } from '@/lib/utils';

const CartPage = () => {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isApplyingCoupon, setIsApplyingCoupon] = useState(false);
  const [couponCode, setCouponCode] = useState('');
  
  // Default userId for demo purposes - in a real app this would come from authentication
  const userId = 1;

  // Fetch cart items
  const { data: cartItems = [], isLoading } = useQuery({
    queryKey: ['/api/cart', userId],
    queryFn: async () => {
      const res = await fetch(`/api/cart?userId=${userId}`);
      if (!res.ok) throw new Error('Failed to fetch cart items');
      return res.json();
    }
  });

  // Remove from cart mutation
  const removeFromCartMutation = useMutation({
    mutationFn: async (cartItemId: number) => {
      return apiRequest('DELETE', `/api/cart/${cartItemId}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      toast({
        title: "Item removed",
        description: "Item has been removed from your shopping bag",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to remove item. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Update quantity mutation
  const updateQuantityMutation = useMutation({
    mutationFn: async ({ id, quantity }: { id: number; quantity: number }) => {
      return apiRequest('PATCH', `/api/cart/${id}`, { quantity });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update quantity. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Move to wishlist mutation
  const moveToWishlistMutation = useMutation({
    mutationFn: async ({ productId, cartItemId }: { productId: number; cartItemId: number }) => {
      // First add to wishlist
      await apiRequest('POST', '/api/wishlist', { userId, productId });
      // Then remove from cart
      return apiRequest('DELETE', `/api/cart/${cartItemId}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      queryClient.invalidateQueries({ queryKey: ['/api/wishlist'] });
      toast({
        title: "Moved to wishlist",
        description: "Item has been moved to your wishlist",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to move item to wishlist. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Apply coupon (mock)
  const applyCoupon = () => {
    setIsApplyingCoupon(true);
    setTimeout(() => {
      setIsApplyingCoupon(false);
      if (couponCode.toUpperCase() === 'WELCOME10') {
        toast({
          title: "Coupon applied",
          description: "10% discount has been applied to your order",
        });
      } else {
        toast({
          title: "Invalid coupon",
          description: "The coupon code you entered is invalid or expired",
          variant: "destructive",
        });
      }
    }, 1000);
  };

  // Calculate cart totals
  const cartSubtotal = cartItems.reduce(
    (total: number, item: any) => total + (item.product.price * item.quantity), 
    0
  );
  
  const estimatedTax = Math.round(cartSubtotal * 0.18); // Assuming 18% GST
  const shippingFee = cartSubtotal >= 999 ? 0 : 99;
  const discount = couponCode.toUpperCase() === 'WELCOME10' ? Math.round(cartSubtotal * 0.1) : 0;
  const orderTotal = cartSubtotal + estimatedTax + shippingFee - discount;

  // Proceed to checkout
  const proceedToCheckout = () => {
    navigate('/checkout');
  };

  // Proceed to Stripe checkout
  const proceedToStripeCheckout = () => {
    navigate('/stripe-checkout');
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-8">Shopping Bag</h1>

      {isLoading ? (
        <div className="flex justify-center p-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#FF3F6C]"></div>
        </div>
      ) : cartItems.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <div className="flex justify-center mb-4">
            <ShoppingBag size={64} className="text-gray-300" />
          </div>
          <h2 className="text-xl font-semibold mb-2">Your shopping bag is empty</h2>
          <p className="text-[#696B79] mb-6">
            Looks like you haven't added anything to your bag yet. 
            Start shopping to add items to your bag.
          </p>
          <Link href="/products">
            <Button className="bg-[#FF3F6C] hover:bg-[#FF3F6C]/90 text-white">
              Continue Shopping
            </Button>
          </Link>
        </div>
      ) : (
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Cart Items */}
          <div className="lg:w-2/3">
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="p-4 border-b">
                <h2 className="font-semibold">
                  Cart Items ({cartItems.length})
                </h2>
              </div>
              
              <div>
                {cartItems.map((item: any) => (
                  <div key={item.id} className="p-4 border-b flex flex-col sm:flex-row">
                    <div className="sm:w-28 sm:h-32 mb-4 sm:mb-0">
                      <img 
                        src={item.product.images[0]} 
                        alt={item.product.name} 
                        className="w-full h-full object-cover rounded"
                      />
                    </div>
                    <div className="flex-1 sm:ml-4">
                      <div className="flex flex-wrap justify-between mb-2">
                        <div>
                          <h3 className="font-medium">{item.product.brand}</h3>
                          <p className="text-[#696B79] text-sm">{item.product.name}</p>
                        </div>
                        <div className="flex items-center mt-2 sm:mt-0">
                          <span className="font-semibold mr-2">₹{item.product.price.toLocaleString('en-IN')}</span>
                          <span className="text-sm text-gray-500 line-through mr-2">₹{item.product.originalPrice.toLocaleString('en-IN')}</span>
                          <span className="text-xs text-[#14CDA2] font-medium">{item.product.discount}% OFF</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center mb-3">
                        <span className="text-sm text-[#696B79] mr-4">Size: {item.size}</span>
                        <span className="text-sm text-[#696B79]">Color: {item.color}</span>
                      </div>
                      
                      <div className="flex flex-wrap justify-between items-center">
                        <div className="flex items-center">
                          <button 
                            className="w-8 h-8 border border-gray-300 rounded-l flex items-center justify-center hover:bg-gray-100 transition-colors"
                            onClick={() => {
                              if (item.quantity > 1) {
                                updateQuantityMutation.mutate({ 
                                  id: item.id, 
                                  quantity: item.quantity - 1 
                                });
                              }
                            }}
                            disabled={updateQuantityMutation.isPending || item.quantity <= 1}
                          >
                            <Minus className="h-3 w-3" />
                          </button>
                          <span className="w-10 h-8 border-t border-b border-gray-300 flex items-center justify-center">
                            {item.quantity}
                          </span>
                          <button 
                            className="w-8 h-8 border border-gray-300 rounded-r flex items-center justify-center hover:bg-gray-100 transition-colors"
                            onClick={() => {
                              if (item.quantity < 10) {
                                updateQuantityMutation.mutate({ 
                                  id: item.id, 
                                  quantity: item.quantity + 1 
                                });
                              }
                            }}
                            disabled={updateQuantityMutation.isPending || item.quantity >= 10}
                          >
                            <Plus className="h-3 w-3" />
                          </button>
                        </div>
                        
                        <div className="flex items-center space-x-4 mt-3 sm:mt-0">
                          <button 
                            className="text-sm text-[#696B79] hover:text-[#FF3F6C] flex items-center"
                            onClick={() => moveToWishlistMutation.mutate({ 
                              productId: item.product.id, 
                              cartItemId: item.id 
                            })}
                            disabled={moveToWishlistMutation.isPending}
                          >
                            <Heart className="h-4 w-4 mr-1" />
                            Wishlist
                          </button>
                          <button 
                            className="text-sm text-[#696B79] hover:text-[#FF3F6C] flex items-center"
                            onClick={() => removeFromCartMutation.mutate(item.id)}
                            disabled={removeFromCartMutation.isPending}
                          >
                            <Trash2 className="h-4 w-4 mr-1" />
                            Remove
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="p-4">
                <div className="rounded border p-4">
                  <h3 className="font-medium mb-3">Have a coupon code?</h3>
                  <div className="flex">
                    <input 
                      type="text" 
                      placeholder="Enter coupon code" 
                      className="flex-1 border border-gray-300 rounded-l px-3 py-2 focus:outline-none focus:ring-1 focus:ring-[#FF3F6C]"
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                    />
                    <Button 
                      className="rounded-l-none bg-[#FF3F6C] hover:bg-[#FF3F6C]/90 text-white"
                      onClick={applyCoupon}
                      disabled={isApplyingCoupon || !couponCode}
                    >
                      {isApplyingCoupon ? 'Applying...' : 'Apply'}
                    </Button>
                  </div>
                  <p className="text-xs text-[#696B79] mt-2">
                    Try coupon code "WELCOME10" for 10% off
                  </p>
                </div>
              </div>
            </div>
            
            <div className="flex justify-between items-center mt-6">
              <Link href="/products">
                <Button variant="outline" className="border-[#FF3F6C] text-[#FF3F6C]">
                  Continue Shopping
                </Button>
              </Link>
              <Button 
                className="bg-[#FF3F6C] hover:bg-[#FF3F6C]/90 text-white hidden sm:flex"
                onClick={proceedToCheckout}
              >
                Proceed to Checkout
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
          
          {/* Order Summary */}
          <div className="lg:w-1/3">
            <div className="bg-white rounded-lg shadow-sm">
              <div className="p-4 border-b">
                <h2 className="font-semibold">Order Summary</h2>
              </div>
              
              <div className="p-4">
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-[#696B79]">Subtotal</span>
                    <span>₹{cartSubtotal.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#696B79]">Estimated Tax</span>
                    <span>₹{estimatedTax.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#696B79]">Shipping</span>
                    <span>{shippingFee === 0 ? 'FREE' : `₹${shippingFee}`}</span>
                  </div>
                  
                  {discount > 0 && (
                    <div className="flex justify-between text-[#14CDA2]">
                      <span>Discount (WELCOME10)</span>
                      <span>- ₹{discount.toLocaleString('en-IN')}</span>
                    </div>
                  )}
                  
                  <Separator className="my-3" />
                  
                  <div className="flex justify-between font-semibold text-lg">
                    <span>Total</span>
                    <span>₹{orderTotal.toLocaleString('en-IN')}</span>
                  </div>
                </div>
                
                <div className="mt-6 space-y-2">
                  <Button 
                    className="w-full bg-[#FF3F6C] hover:bg-[#FF3F6C]/90 text-white"
                    onClick={proceedToCheckout}
                  >
                    Regular Checkout
                  </Button>
                  <Button 
                    className="w-full bg-[#5469d4] hover:bg-[#5469d4]/90 text-white"
                    onClick={proceedToStripeCheckout}
                  >
                    <svg className="w-5 h-5 mr-2" viewBox="0 0 41 16" xmlns="http://www.w3.org/2000/svg">
                      <path d="M11.4402 4.5889C11.4402 4.14852 11.7896 3.97667 12.3929 3.97667C13.2373 3.97667 14.3218 4.24853 15.2034 4.74889V1.64817C14.2469 1.23058 13.2974 1.03059 12.3929 1.03059C9.72951 1.03059 7.93673 2.37343 7.93673 4.76889C7.93673 8.29372 12.6073 7.66296 12.6073 9.30654C12.6073 9.84654 12.1781 10.0184 11.5348 10.0184C10.63 10.0184 9.42558 9.64654 8.4433 9.06654V12.1272C9.5478 12.6431 10.6641 12.8465 11.5348 12.8473C14.2583 12.8473 16.1307 11.5274 16.1307 9.12654C16.1298 5.34854 11.4402 6.07837 11.4402 4.5889ZM25.0742 1.2389H22.2709L22.2358 9.90654C22.2358 11.6065 23.5104 12.8473 25.2103 12.8473C26.3298 12.8473 27.1383 12.6273 27.6365 12.3274V9.50697C27.1553 9.72695 25.0724 10.2273 25.0724 8.3067V4.36852H27.6365V1.2389H25.0724L25.0742 1.2389ZM33.0558 1.2389L30.1725 1.23851V12.6471H33.0558V1.2389ZM3.9946 1.2389L1.0769 1.23851V12.6471H3.9946V1.2389ZM31.6141 0C30.653 0 29.8752 0.77193 29.8752 1.7273C29.8752 2.68192 30.6521 3.4539 31.6141 3.4539C32.5753 3.4539 33.3576 2.68192 33.3576 1.7273C33.3576 0.77193 32.5753 0 31.6141 0ZM3.98469 0C3.02357 0 2.24577 0.77193 2.24577 1.7273C2.24577 2.68192 3.02267 3.4539 3.98469 3.4539C4.94577 3.4539 5.7281 2.68192 5.7281 1.7273C5.7281 0.77193 4.94577 0 3.98469 0ZM21.0325 3.5923C19.9328 3.5923 19.1435 4.17189 18.7635 4.7923L18.685 1.2389H15.8025V12.6471H18.685V7.12737C19.065 6.28737 19.725 5.68737 20.6599 5.68737C21.7596 5.68737 22.4204 6.3673 22.4204 7.9073V12.6471H25.3037V7.42737C25.3037 5.07775 23.6448 3.5923 21.0325 3.5923Z" fill="white" fillRule="nonzero" />
                      <path d="M37.0209 5.3874C36.1209 5.3874 35.5209 5.9874 35.5209 6.8874C35.5209 7.7874 36.1209 8.3874 37.0209 8.3874C37.9209 8.3874 38.5209 7.7874 38.5209 6.8874C38.5209 5.9874 37.9209 5.3874 37.0209 5.3874Z" fill="white" />
                      <path d="M38.8994 10.2483C38.8994 9.8483 38.5994 9.6483 38.0994 9.6483C37.5994 9.6483 37.1994 9.8483 37.1994 10.2483C37.1994 10.6483 37.4994 10.8483 37.9994 10.8483C38.4994 10.8483 38.8994 10.6483 38.8994 10.2483Z" fill="white" />
                      <path d="M38.8994 11.5482C38.8994 11.1482 38.5994 10.9482 38.0994 10.9482C37.5994 10.9482 37.1994 11.1482 37.1994 11.5482C37.1994 11.9482 37.4994 12.1482 37.9994 12.1482C38.4994 12.1482 38.8994 11.9482 38.8994 11.5482Z" fill="white" />
                      <path d="M37.8994 13.2482C37.8994 12.9482 37.6994 12.7482 37.3994 12.7482C37.0994 12.7482 36.8994 12.9482 36.8994 13.2482C36.8994 13.5482 37.0994 13.7482 37.3994 13.7482C37.6994 13.7482 37.8994 13.5482 37.8994 13.2482Z" fill="white" />
                      <path d="M40.7006 11.5482C40.7006 11.1482 40.4006 10.9482 39.9006 10.9482C39.4006 10.9482 39.0006 11.1482 39.0006 11.5482C39.0006 11.9482 39.3006 12.1482 39.8006 12.1482C40.3006 12.1482 40.7006 11.9482 40.7006 11.5482Z" fill="white" />
                      <path d="M39.7006 13.2482C39.7006 12.9482 39.5006 12.7482 39.2006 12.7482C38.9006 12.7482 38.7006 12.9482 38.7006 13.2482C38.7006 13.5482 38.9006 13.7482 39.2006 13.7482C39.5006 13.7482 39.7006 13.5482 39.7006 13.2482Z" fill="white" />
                      <path d="M39.7006 10.2483C39.7006 9.8483 39.4006 9.6483 38.9006 9.6483C38.4006 9.6483 38.0006 9.8483 38.0006 10.2483C38.0006 10.6483 38.3006 10.8483 38.8006 10.8483C39.3006 10.8483 39.7006 10.6483 39.7006 10.2483Z" fill="white" />
                    </svg>
                    Pay with Stripe
                  </Button>
                </div>
                
                <div className="mt-4 p-3 border border-green-200 bg-green-50 rounded text-sm">
                  <div className="flex items-center text-green-700 mb-1">
                    <Truck className="h-4 w-4 mr-2" />
                    <span className="font-medium">Congratulations!</span>
                  </div>
                  <p className="text-green-700">
                    {cartSubtotal >= 999 
                      ? 'You got FREE delivery on this order!' 
                      : `Add items worth ₹${(999 - cartSubtotal).toLocaleString('en-IN')} more for FREE delivery`}
                  </p>
                </div>
                
                <div className="mt-6">
                  <h3 className="font-medium mb-2">Accepted Payment Methods</h3>
                  <div className="flex space-x-2">
                    <img src="https://img.icons8.com/color/48/null/visa.png" alt="Visa" className="h-8" />
                    <img src="https://img.icons8.com/color/48/null/mastercard.png" alt="Mastercard" className="h-8" />
                    <img src="https://img.icons8.com/color/48/null/amex.png" alt="American Express" className="h-8" />
                    <img src="https://img.icons8.com/color/48/null/paypal.png" alt="PayPal" className="h-8" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CartPage;
