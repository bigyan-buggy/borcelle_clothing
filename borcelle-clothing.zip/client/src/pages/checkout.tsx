import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { 
  CreditCard, 
  Wallet, 
  Building, 
  Check, 
  Plus, 
  Home, 
  MapPin,
  ArrowRight,
  ArrowLeft,
  ChevronsUpDown
} from 'lucide-react';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { formatPrice } from '@/lib/utils';

// Form validation schema
const addressSchema = z.object({
  name: z.string().min(3, 'Name must be at least 3 characters'),
  address: z.string().min(5, 'Address must be at least 5 characters'),
  city: z.string().min(2, 'City is required'),
  state: z.string().min(2, 'State is required'),
  pincode: z.string().length(6, 'Pincode must be 6 digits'),
  phoneNumber: z.string().min(10, 'Phone number must be at least 10 digits'),
  isDefault: z.boolean().default(false),
});

const CheckoutPage = () => {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeStep, setActiveStep] = useState<'address' | 'payment'>('address');
  const [selectedAddress, setSelectedAddress] = useState<number | null>(null);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<string>('card');
  const [isPlacingOrder, setIsPlacingOrder] = useState(false);
  
  // Default userId for demo purposes - in a real app this would come from authentication
  const userId = 1;

  // Form
  const form = useForm<z.infer<typeof addressSchema>>({
    resolver: zodResolver(addressSchema),
    defaultValues: {
      name: '',
      address: '',
      city: '',
      state: '',
      pincode: '',
      phoneNumber: '',
      isDefault: false,
    },
  });

  // Fetch cart items
  const { data: cartItems = [], isLoading: cartLoading } = useQuery({
    queryKey: ['/api/cart', userId],
    queryFn: async () => {
      const res = await fetch(`/api/cart?userId=${userId}`);
      if (!res.ok) throw new Error('Failed to fetch cart items');
      return res.json();
    }
  });

  // Fetch user profile (for addresses)
  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ['/api/users', userId],
    queryFn: async () => {
      // Mock response for demo
      return {
        id: 1,
        name: 'John Doe',
        email: 'john@example.com',
        addresses: [
          {
            id: 1,
            name: 'John Doe',
            address: '123 Main Street, Apartment 4B',
            city: 'Mumbai',
            state: 'Maharashtra',
            pincode: '400001',
            phoneNumber: '9876543210',
            isDefault: true
          },
          {
            id: 2,
            name: 'John Doe',
            address: '456 Park Avenue',
            city: 'Bangalore',
            state: 'Karnataka',
            pincode: '560001',
            phoneNumber: '9876543210',
            isDefault: false
          }
        ]
      };
    }
  });

  // Place order mutation
  const placeOrderMutation = useMutation({
    mutationFn: async () => {
      // In a real app, this would call the API
      setIsPlacingOrder(true);
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Create order items from cart
      const items = cartItems.map((item: any) => ({
        productId: item.product.id,
        name: item.product.name,
        brand: item.product.brand,
        price: item.product.price,
        originalPrice: item.product.originalPrice,
        quantity: item.quantity,
        size: item.size,
        color: item.color,
        imageUrl: item.product.images[0]
      }));
      
      // Get selected address
      const address = user.addresses.find(addr => addr.id === selectedAddress) || user.addresses[0];
      
      // Calculate totals
      const subtotal = cartItems.reduce(
        (total: number, item: any) => total + (item.product.price * item.quantity), 
        0
      );
      const tax = Math.round(subtotal * 0.18);
      const shipping = subtotal >= 999 ? 0 : 99;
      const total = subtotal + tax + shipping;
      
      return apiRequest('POST', '/api/orders', {
        userId,
        orderNumber: `ORD-${Date.now()}`,
        status: 'pending',
        total,
        tax,
        shipping,
        shippingAddress: address,
        items,
        paymentMethod: selectedPaymentMethod
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      queryClient.invalidateQueries({ queryKey: ['/api/orders'] });
      
      // Navigate to order success page
      toast({
        title: "Order placed successfully!",
        description: "Thank you for shopping with us."
      });
      
      // In a real app, you would navigate to an order confirmation page
      // with the order details
      navigate('/profile');
    },
    onError: (error) => {
      toast({
        title: "Failed to place order",
        description: "Please try again later",
        variant: "destructive"
      });
      setIsPlacingOrder(false);
    },
    onSettled: () => {
      setIsPlacingOrder(false);
    }
  });

  // Calculate cart totals
  const cartSubtotal = cartItems.reduce(
    (total: number, item: any) => total + (item.product.price * item.quantity), 
    0
  );
  
  const estimatedTax = Math.round(cartSubtotal * 0.18); // Assuming 18% GST
  const shippingFee = cartSubtotal >= 999 ? 0 : 99;
  const orderTotal = cartSubtotal + estimatedTax + shippingFee;

  const onSubmitAddress = (values: z.infer<typeof addressSchema>) => {
    // In a real app, this would call the API to add/update address
    toast({
      title: "Address saved",
      description: "Your delivery address has been saved."
    });
    
    // Add the address to the user object (for demo purposes)
    const newAddressId = (user?.addresses?.length || 0) + 1;
    queryClient.setQueryData(['/api/users', userId], {
      ...user,
      addresses: [
        ...(user?.addresses || []),
        { ...values, id: newAddressId }
      ]
    });
    
    setSelectedAddress(newAddressId);
  };

  const handleAddressSelect = (addressId: number) => {
    setSelectedAddress(addressId);
  };

  const handleContinueToPayment = () => {
    if (!selectedAddress && (!user?.addresses || user.addresses.length === 0)) {
      toast({
        title: "Address required",
        description: "Please add a delivery address to continue.",
        variant: "destructive"
      });
      return;
    }
    
    if (!selectedAddress && user?.addresses && user.addresses.length > 0) {
      // Default to the first address if none selected
      setSelectedAddress(user.addresses[0].id);
    }
    
    setActiveStep('payment');
  };

  const handleBackToAddress = () => {
    setActiveStep('address');
  };

  const handlePlaceOrder = () => {
    if (!selectedAddress) {
      toast({
        title: "Address required",
        description: "Please select a delivery address to continue.",
        variant: "destructive"
      });
      return;
    }
    
    if (!selectedPaymentMethod) {
      toast({
        title: "Payment method required",
        description: "Please select a payment method to continue.",
        variant: "destructive"
      });
      return;
    }
    
    placeOrderMutation.mutate();
  };

  if (cartLoading || userLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#FF3F6C]"></div>
      </div>
    );
  }

  if (!cartItems || cartItems.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <div className="text-gray-400 text-6xl mb-4">
          <i className="fas fa-shopping-bag"></i>
        </div>
        <h1 className="text-2xl font-bold mb-2">Your shopping bag is empty</h1>
        <p className="text-[#696B79] mb-8">
          Add items to your bag to proceed to checkout.
        </p>
        <Button 
          className="bg-[#FF3F6C] hover:bg-[#FF3F6C]/90 text-white"
          onClick={() => navigate('/products')}
        >
          Continue Shopping
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold">Checkout</h1>
        <div className="flex items-center mt-4">
          <div className={`flex items-center justify-center w-8 h-8 rounded-full ${activeStep === 'address' ? 'bg-[#FF3F6C] text-white' : 'bg-[#14CDA2] text-white'}`}>
            {activeStep === 'address' ? '1' : <Check size={16} />}
          </div>
          <div className={`flex-1 h-1 mx-4 ${activeStep === 'address' ? 'bg-gray-300' : 'bg-[#14CDA2]'}`}></div>
          <div className={`flex items-center justify-center w-8 h-8 rounded-full ${activeStep === 'payment' ? 'bg-[#FF3F6C] text-white' : 'bg-gray-300 text-gray-600'}`}>
            2
          </div>
        </div>
        <div className="flex justify-between mt-2">
          <span className={activeStep === 'address' ? 'text-[#FF3F6C] font-medium' : 'text-[#14CDA2] font-medium'}>
            Delivery Address
          </span>
          <span className={activeStep === 'payment' ? 'text-[#FF3F6C] font-medium' : 'text-gray-500'}>
            Payment Method
          </span>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Left Column - Address & Payment */}
        <div className="lg:w-2/3">
          {activeStep === 'address' && (
            <Card>
              <CardHeader>
                <CardTitle>Select Delivery Address</CardTitle>
              </CardHeader>
              <CardContent>
                {/* Existing Addresses */}
                {user?.addresses && user.addresses.length > 0 && (
                  <div className="mb-6">
                    <div className="space-y-4">
                      {user.addresses.map((address) => (
                        <div 
                          key={address.id}
                          className={`border rounded-md p-4 cursor-pointer transition-colors ${selectedAddress === address.id ? 'border-[#FF3F6C] bg-[#FF3F6C]/5' : 'border-gray-200 hover:border-[#FF3F6C]'}`}
                          onClick={() => handleAddressSelect(address.id)}
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex items-start">
                              <RadioGroupItem 
                                value={`address-${address.id}`} 
                                id={`address-${address.id}`}
                                className="mt-1 mr-3"
                                checked={selectedAddress === address.id}
                                onClick={() => handleAddressSelect(address.id)}
                              />
                              <div>
                                <div className="flex items-center mb-1">
                                  <span className="font-medium mr-2">{address.name}</span>
                                  {address.isDefault && (
                                    <span className="bg-gray-200 text-gray-800 text-xs px-2 py-1 rounded">
                                      Default
                                    </span>
                                  )}
                                </div>
                                <div className="text-sm text-[#696B79]">
                                  <p>{address.address}</p>
                                  <p>{address.city}, {address.state} - {address.pincode}</p>
                                  <p className="mt-1">Phone: {address.phoneNumber}</p>
                                </div>
                              </div>
                            </div>
                            <Button variant="ghost" size="sm" className="text-[#FF3F6C]">
                              Edit
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Add New Address */}
                <Accordion type="single" collapsible>
                  <AccordionItem value="add-address">
                    <AccordionTrigger className="text-[#FF3F6C]">
                      <div className="flex items-center">
                        <Plus size={18} className="mr-2" />
                        Add New Address
                      </div>
                    </AccordionTrigger>
                    <AccordionContent>
                      <Form {...form}>
                        <form onSubmit={form.handleSubmit(onSubmitAddress)} className="space-y-4">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField
                              control={form.control}
                              name="name"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Full Name</FormLabel>
                                  <FormControl>
                                    <Input placeholder="John Doe" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={form.control}
                              name="phoneNumber"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Phone Number</FormLabel>
                                  <FormControl>
                                    <Input placeholder="10-digit mobile number" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                            
                          <FormField
                            control={form.control}
                            name="address"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Address</FormLabel>
                                <FormControl>
                                  <Textarea placeholder="House No., Building Name, Street, Area" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                            
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <FormField
                              control={form.control}
                              name="city"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>City</FormLabel>
                                  <FormControl>
                                    <Input placeholder="City" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={form.control}
                              name="state"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>State</FormLabel>
                                  <Select
                                    onValueChange={field.onChange}
                                    defaultValue={field.value}
                                  >
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select State" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="maharashtra">Maharashtra</SelectItem>
                                      <SelectItem value="delhi">Delhi</SelectItem>
                                      <SelectItem value="karnataka">Karnataka</SelectItem>
                                      <SelectItem value="tamil-nadu">Tamil Nadu</SelectItem>
                                      <SelectItem value="uttar-pradesh">Uttar Pradesh</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={form.control}
                              name="pincode"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Pincode</FormLabel>
                                  <FormControl>
                                    <Input placeholder="6-digit pincode" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                            
                          <FormField
                            control={form.control}
                            name="isDefault"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                                <FormControl>
                                  <input
                                    type="checkbox"
                                    checked={field.value}
                                    onChange={field.onChange}
                                    className="h-4 w-4 rounded border-gray-300 text-[#FF3F6C] focus:ring-[#FF3F6C]"
                                  />
                                </FormControl>
                                <div className="space-y-1 leading-none">
                                  <FormLabel>
                                    Make this my default address
                                  </FormLabel>
                                </div>
                              </FormItem>
                            )}
                          />
                            
                          <Button 
                            type="submit"
                            className="bg-[#FF3F6C] hover:bg-[#FF3F6C]/90 text-white"
                          >
                            Save Address
                          </Button>
                        </form>
                      </Form>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>

                <div className="mt-6 flex justify-end">
                  <Button 
                    className="bg-[#FF3F6C] hover:bg-[#FF3F6C]/90 text-white"
                    onClick={handleContinueToPayment}
                  >
                    Continue to Payment
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {activeStep === 'payment' && (
            <Card>
              <CardHeader>
                <CardTitle>Payment Method</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="card" onValueChange={(value) => setSelectedPaymentMethod(value)}>
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="card">Credit/Debit Card</TabsTrigger>
                    <TabsTrigger value="upi">UPI/Wallet</TabsTrigger>
                    <TabsTrigger value="cod">Cash on Delivery</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="card" className="p-4 border rounded-md mt-4">
                    <div className="space-y-4">
                      <div>
                        <FormLabel>Card Number</FormLabel>
                        <Input 
                          placeholder="1234 5678 9012 3456" 
                          className="mt-1"
                        />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <FormLabel>Expiry Date</FormLabel>
                          <Input 
                            placeholder="MM/YY" 
                            className="mt-1"
                          />
                        </div>
                        <div>
                          <FormLabel>CVV</FormLabel>
                          <Input 
                            placeholder="123" 
                            className="mt-1"
                            type="password"
                          />
                        </div>
                      </div>
                      
                      <div>
                        <FormLabel>Name on Card</FormLabel>
                        <Input 
                          placeholder="John Doe" 
                          className="mt-1"
                        />
                      </div>
                      
                      <div className="flex items-center mt-4">
                        <input
                          type="checkbox"
                          id="save-card"
                          className="h-4 w-4 rounded border-gray-300 text-[#FF3F6C] focus:ring-[#FF3F6C]"
                        />
                        <label htmlFor="save-card" className="ml-2 text-sm text-gray-700">
                          Save card for faster payments
                        </label>
                      </div>
                      
                      <div className="flex items-center justify-between bg-gray-50 p-3 rounded-md">
                        <div className="flex items-center">
                          <CreditCard className="h-5 w-5 text-[#696B79] mr-2" />
                          <span className="text-sm">All cards accepted</span>
                        </div>
                        <div className="flex space-x-2">
                          <img src="https://img.icons8.com/color/48/null/visa.png" alt="Visa" className="h-6" />
                          <img src="https://img.icons8.com/color/48/null/mastercard.png" alt="Mastercard" className="h-6" />
                          <img src="https://img.icons8.com/color/48/null/amex.png" alt="American Express" className="h-6" />
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="upi" className="p-4 border rounded-md mt-4">
                    <div className="space-y-4">
                      <div>
                        <FormLabel>UPI ID</FormLabel>
                        <Input 
                          placeholder="yourname@upi" 
                          className="mt-1"
                        />
                      </div>
                      
                      <p className="text-sm text-[#696B79]">
                        Please enter your UPI ID in the format username@bankname
                      </p>
                      
                      <div className="flex items-center justify-between bg-gray-50 p-3 rounded-md">
                        <div className="flex items-center">
                          <Wallet className="h-5 w-5 text-[#696B79] mr-2" />
                          <span className="text-sm">All UPI apps supported</span>
                        </div>
                        <div className="flex space-x-2">
                          <img src="https://img.icons8.com/color/48/null/google-pay-india.png" alt="Google Pay" className="h-6" />
                          <img src="https://img.icons8.com/color/48/null/phonepe.png" alt="PhonePe" className="h-6" />
                          <img src="https://img.icons8.com/color/48/null/bhim.png" alt="BHIM" className="h-6" />
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="cod" className="p-4 border rounded-md mt-4">
                    <div className="space-y-4">
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          id="cod"
                          checked={true}
                          readOnly
                          className="h-4 w-4 rounded border-gray-300 text-[#FF3F6C] focus:ring-[#FF3F6C]"
                        />
                        <label htmlFor="cod" className="ml-2 font-medium">
                          Cash on Delivery
                        </label>
                      </div>
                      
                      <p className="text-sm text-[#696B79]">
                        Pay at your doorstep when the package arrives. Additional ₹40 fee applies for COD orders.
                      </p>
                      
                      <div className="flex items-center bg-amber-50 p-3 rounded-md">
                        <Building className="h-5 w-5 text-amber-500 mr-2" />
                        <span className="text-sm text-amber-700">
                          COD may not be available for some remote locations. If your area is not serviceable, you will be notified.
                        </span>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>

                <div className="mt-6 flex justify-between">
                  <Button 
                    variant="outline" 
                    className="border-[#FF3F6C] text-[#FF3F6C]"
                    onClick={handleBackToAddress}
                  >
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Back to Address
                  </Button>
                  <Button 
                    className="bg-[#FF3F6C] hover:bg-[#FF3F6C]/90 text-white"
                    onClick={handlePlaceOrder}
                    disabled={isPlacingOrder}
                  >
                    {isPlacingOrder ? (
                      <>
                        <div className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
                        Processing...
                      </>
                    ) : 'Place Order'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
        
        {/* Right Column - Order Summary */}
        <div className="lg:w-1/3">
          <Card>
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="max-h-60 overflow-y-auto mb-4">
                {cartItems.map((item: any) => (
                  <div key={item.id} className="flex py-3 border-b">
                    <div className="w-16 h-20 bg-gray-100 rounded overflow-hidden">
                      <img 
                        src={item.product.images[0]} 
                        alt={item.product.name} 
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="ml-3 flex-1">
                      <p className="text-sm font-medium">{item.product.brand}</p>
                      <p className="text-xs text-[#696B79]">{item.product.name}</p>
                      <div className="flex items-center mt-1 text-xs text-[#696B79]">
                        <span>Size: {item.size}</span>
                        <span className="mx-2">|</span>
                        <span>Qty: {item.quantity}</span>
                      </div>
                      <div className="flex items-center mt-1">
                        <span className="text-sm font-semibold">₹{item.product.price.toLocaleString('en-IN')}</span>
                        <span className="text-xs text-gray-500 line-through ml-2">₹{item.product.originalPrice.toLocaleString('en-IN')}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-[#696B79]">Subtotal</span>
                  <span>₹{cartSubtotal.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#696B79]">Estimated Tax</span>
                  <span>₹{estimatedTax.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#696B79]">Shipping</span>
                  <span>{shippingFee === 0 ? 'FREE' : `₹${shippingFee}`}</span>
                </div>
                
                <Separator className="my-3" />
                
                <div className="flex justify-between font-semibold text-lg">
                  <span>Total</span>
                  <span>₹{orderTotal.toLocaleString('en-IN')}</span>
                </div>
              </div>
              
              {/* Selected Address Summary */}
              {activeStep === 'payment' && selectedAddress && user?.addresses && (
                <div className="mt-6 border-t pt-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium">Delivery Address</h3>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-[#FF3F6C] h-8 px-2"
                      onClick={handleBackToAddress}
                    >
                      Change
                    </Button>
                  </div>
                  
                  {user.addresses.filter(a => a.id === selectedAddress).map((address) => (
                    <div key={address.id} className="text-sm">
                      <p className="font-medium">{address.name}</p>
                      <p className="text-[#696B79]">{address.address}</p>
                      <p className="text-[#696B79]">{address.city}, {address.state} - {address.pincode}</p>
                      <p className="text-[#696B79] mt-1">Phone: {address.phoneNumber}</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;
