import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Check, CreditCard, ShoppingBag } from 'lucide-react';
import { formatPrice } from '@/lib/utils';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const CheckoutForm = ({ amount }: { amount: number }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [_, navigate] = useLocation();
  const queryClient = useQueryClient();
  
  // Mock user ID - in a real app, this would come from auth context
  const userId = 1;
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    try {
      const { error, paymentIntent } = await stripe.confirmPayment({
        elements,
        redirect: 'if_required',
      });

      if (error) {
        toast({
          title: "Payment Failed",
          description: error.message,
          variant: "destructive",
        });
        setIsProcessing(false);
        return;
      }

      if (paymentIntent && paymentIntent.status === 'succeeded') {
        // Get cart and user data
        const cartItems = await fetch(`/api/cart?userId=${userId}`).then(res => res.json());
        const user = await fetch(`/api/users/${userId}`).then(res => {
          // If user endpoint is not available, return mock data
          if (!res.ok) {
            return {
              id: userId,
              addresses: [{
                name: "John Doe",
                address: "123 Main Street",
                city: "New York",
                state: "NY",
                pincode: "10001",
                phoneNumber: "1234567890",
                isDefault: true
              }]
            };
          }
          return res.json();
        });

        // Get selected address
        const address = user.addresses?.find((addr: any) => addr.isDefault) || user.addresses?.[0];

        // Calculate totals
        const subtotal = cartItems.reduce(
          (total: number, item: any) => total + (item.product.price * item.quantity), 
          0
        );
        const tax = Math.round(subtotal * 0.18);
        const shipping = subtotal >= 999 ? 0 : 99;

        // Process payment and create order
        await apiRequest('POST', '/api/process-payment', {
          paymentIntentId: paymentIntent.id,
          userId,
          address,
          cartItems,
          subtotal,
          tax,
          shipping
        });

        // Invalidate cart queries
        queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
        
        toast({
          title: "Payment Successful",
          description: "Thank you for your purchase! Your order has been placed successfully.",
        });
        
        // Navigate to order success page
        navigate('/profile');
      } else {
        toast({
          title: "Payment Processing",
          description: "Your payment is being processed. We'll notify you once it's complete.",
        });
      }
    } catch (err) {
      console.error('Error processing payment:', err);
      toast({
        title: "Payment Error",
        description: "There was a problem processing your payment. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      <Button
        type="submit"
        disabled={!stripe || isProcessing}
        className="w-full bg-[#FF3F6C] hover:bg-[#FF3F6C]/90 text-white"
      >
        {isProcessing ? (
          <div className="flex items-center">
            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
            Processing...
          </div>
        ) : (
          <>Pay {formatPrice(amount)}</>
        )}
      </Button>
    </form>
  );
};

const OrderSummary = ({ amount }: { amount: number }) => {
  const [_, navigate] = useLocation();
  const userId = 1; // Mock user ID

  const { data: cartItems = [], isLoading } = useQuery({
    queryKey: ['/api/cart', userId],
    queryFn: async () => {
      const res = await fetch(`/api/cart?userId=${userId}`);
      if (!res.ok) throw new Error('Failed to fetch cart items');
      return res.json();
    }
  });

  // Calculate cart totals
  const cartSubtotal = cartItems.reduce(
    (total: number, item: any) => total + (item.product.price * item.quantity), 
    0
  );
  
  const estimatedTax = Math.round(cartSubtotal * 0.18); // Assuming 18% GST
  const shippingFee = cartSubtotal >= 999 ? 0 : 99;
  const orderTotal = cartSubtotal + estimatedTax + shippingFee;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Order Summary</CardTitle>
        <Button 
          variant="ghost" 
          size="sm" 
          className="text-[#FF3F6C] -mt-2"
          onClick={() => navigate('/cart')}
        >
          <ArrowLeft className="w-4 h-4 mr-1" />
          Back to Cart
        </Button>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
            <Skeleton className="h-5 w-full" />
            <Skeleton className="h-5 w-full" />
            <Skeleton className="h-5 w-full" />
          </div>
        ) : (
          <>
            <div className="space-y-3 mb-3">
              {cartItems.map((item: any) => (
                <div key={item.id} className="flex justify-between">
                  <div className="flex items-start">
                    <div className="w-12 h-12 rounded overflow-hidden flex-shrink-0 mr-3">
                      <img 
                        src={item.product.images[0]} 
                        alt={item.product.name} 
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <p className="text-sm font-medium line-clamp-1">{item.product.name}</p>
                      <p className="text-xs text-gray-500">
                        Size: {item.size} | Qty: {item.quantity}
                      </p>
                    </div>
                  </div>
                  <p className="text-sm font-medium">
                    {formatPrice(item.product.price * item.quantity)}
                  </p>
                </div>
              ))}
            </div>
            <Separator className="my-4" />
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Subtotal</span>
                <span>{formatPrice(cartSubtotal)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Estimated Tax</span>
                <span>{formatPrice(estimatedTax)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Shipping & Handling</span>
                <span>{shippingFee === 0 ? 'FREE' : formatPrice(shippingFee)}</span>
              </div>
              <Separator className="my-2" />
              <div className="flex justify-between font-medium">
                <span>Total</span>
                <span>{formatPrice(orderTotal)}</span>
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default function StripeCheckout() {
  const [clientSecret, setClientSecret] = useState("");
  const { toast } = useToast();
  const userId = 1; // Mock user ID

  // Fetch cart items to calculate amount
  const { data: cartItems = [] } = useQuery({
    queryKey: ['/api/cart', userId],
    queryFn: async () => {
      try {
        const res = await fetch(`/api/cart?userId=${userId}`);
        if (!res.ok) return [];
        return res.json();
      } catch (err) {
        console.error('Error fetching cart:', err);
        return [];
      }
    }
  });

  // Calculate total amount
  const cartSubtotal = cartItems.reduce(
    (total: number, item: any) => total + (item.product.price * item.quantity), 
    0
  );
  const estimatedTax = Math.round(cartSubtotal * 0.18);
  const shippingFee = cartSubtotal >= 999 ? 0 : 99;
  const orderTotal = cartSubtotal + estimatedTax + shippingFee;

  useEffect(() => {
    // Don't create a payment intent if cart is empty
    if (cartItems.length === 0 || orderTotal === 0) return;

    // Create PaymentIntent as soon as the page loads
    const createPaymentIntent = async () => {
      try {
        const response = await apiRequest("POST", "/api/create-payment-intent", { 
          amount: orderTotal 
        });
        const data = await response.json();
        setClientSecret(data.clientSecret);
      } catch (err) {
        console.error('Error creating payment intent:', err);
        toast({
          title: "Payment Setup Failed",
          description: "There was a problem setting up the payment. Please try again.",
          variant: "destructive",
        });
      }
    };

    createPaymentIntent();
  }, [orderTotal, cartItems.length, toast]);

  // If cart is empty, show a message
  if (cartItems.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <div className="text-gray-400 text-6xl mb-4">
          <ShoppingBag className="mx-auto" />
        </div>
        <h1 className="text-2xl font-bold mb-2">Your shopping bag is empty</h1>
        <p className="text-[#696B79] mb-8">
          Add items to your bag to proceed to checkout.
        </p>
        <Button 
          className="bg-[#FF3F6C] hover:bg-[#FF3F6C]/90 text-white"
          onClick={() => window.location.href = '/products'}
        >
          Continue Shopping
        </Button>
      </div>
    );
  }

  if (!clientSecret) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-5xl mx-auto">
          <h1 className="text-2xl font-bold mb-6">Checkout</h1>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardContent className="p-6">
                  <div className="flex justify-center items-center h-64">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#FF3F6C]"></div>
                  </div>
                </CardContent>
              </Card>
            </div>
            <div className="lg:col-span-1">
              <OrderSummary amount={orderTotal} />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">Checkout</h1>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Payment Method</CardTitle>
                <CardDescription>
                  All transactions are secure and encrypted
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Elements stripe={stripePromise} options={{ clientSecret }}>
                  <CheckoutForm amount={orderTotal} />
                </Elements>
              </CardContent>
              <CardFooter className="flex-col items-start text-sm text-gray-500 space-y-2">
                <div className="flex items-center">
                  <Check className="w-4 h-4 mr-2 text-green-500" />
                  <span>Your information is secure and encrypted</span>
                </div>
                <div className="flex items-center">
                  <CreditCard className="w-4 h-4 mr-2 text-green-500" />
                  <span>We accept all major credit cards</span>
                </div>
              </CardFooter>
            </Card>
          </div>
          <div className="lg:col-span-1">
            <OrderSummary amount={orderTotal} />
          </div>
        </div>
      </div>
    </div>
  );
}