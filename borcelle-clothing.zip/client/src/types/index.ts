export interface Product {
  id: number;
  name: string;
  brand: string;
  description: string;
  slug: string;
  price: number;
  originalPrice: number;
  discount: number;
  categoryId: number;
  images: string[];
  sizes: string[];
  colors: { name: string; code: string }[];
  tags?: string[];
  isFeatured: boolean;
  isNew: boolean;
  isTrending: boolean;
  isBestSeller: boolean;
  stock: number;
  createdAt: Date;
}

export interface Category {
  id: number;
  name: string;
  slug: string;
  description?: string;
  imageUrl?: string;
}

export interface CartItem {
  id: number;
  userId: number;
  productId: number;
  size: string;
  color: string;
  quantity: number;
  createdAt: Date;
  product?: Product;
}

export interface WishlistItem {
  id: number;
  userId: number;
  productId: number;
  createdAt: Date;
  product?: Product;
}

export interface Address {
  id?: number;
  name: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  phoneNumber: string;
  isDefault: boolean;
}

export interface OrderItem {
  productId: number;
  name: string;
  brand: string;
  price: number;
  originalPrice: number;
  quantity: number;
  size: string;
  color: string;
  imageUrl: string;
}

export interface Order {
  id: number;
  userId: number;
  orderNumber: string;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  total: number;
  tax: number;
  shipping: number;
  shippingAddress: Address;
  items: OrderItem[];
  paymentMethod: string;
  createdAt: Date;
}

export interface User {
  id: number;
  username: string;
  name: string;
  email: string;
  phoneNumber?: string;
  addresses?: Address[];
  createdAt: Date;
}
