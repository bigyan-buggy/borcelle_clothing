import { X } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogClose } from '@/components/ui/dialog';

interface SizeGuideProps {
  isOpen: boolean;
  onClose: () => void;
}

const SizeGuide = ({ isOpen, onClose }: SizeGuideProps) => {
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Size Guide</DialogTitle>
          <DialogClose className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground">
            <X className="h-4 w-4" />
            <span className="sr-only">Close</span>
          </DialogClose>
        </DialogHeader>
        
        <div className="p-6">
          <h3 className="font-medium mb-4">Clothing Size Chart (in inches)</h3>
          
          <div className="overflow-x-auto">
            <table className="min-w-full border border-gray-200">
              <thead>
                <tr className="bg-gray-100">
                  <th className="py-2 px-4 border-b text-left">Size</th>
                  <th className="py-2 px-4 border-b text-center">Chest</th>
                  <th className="py-2 px-4 border-b text-center">Waist</th>
                  <th className="py-2 px-4 border-b text-center">Hip</th>
                  <th className="py-2 px-4 border-b text-center">Shoulder</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b">
                  <td className="py-2 px-4 font-medium">XS</td>
                  <td className="py-2 px-4 text-center">34-36</td>
                  <td className="py-2 px-4 text-center">28-30</td>
                  <td className="py-2 px-4 text-center">34-36</td>
                  <td className="py-2 px-4 text-center">14-15</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 px-4 font-medium">S</td>
                  <td className="py-2 px-4 text-center">36-38</td>
                  <td className="py-2 px-4 text-center">30-32</td>
                  <td className="py-2 px-4 text-center">36-38</td>
                  <td className="py-2 px-4 text-center">15-16</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 px-4 font-medium">M</td>
                  <td className="py-2 px-4 text-center">38-40</td>
                  <td className="py-2 px-4 text-center">32-34</td>
                  <td className="py-2 px-4 text-center">38-40</td>
                  <td className="py-2 px-4 text-center">16-17</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 px-4 font-medium">L</td>
                  <td className="py-2 px-4 text-center">40-42</td>
                  <td className="py-2 px-4 text-center">34-36</td>
                  <td className="py-2 px-4 text-center">40-42</td>
                  <td className="py-2 px-4 text-center">17-18</td>
                </tr>
                <tr>
                  <td className="py-2 px-4 font-medium">XL</td>
                  <td className="py-2 px-4 text-center">42-44</td>
                  <td className="py-2 px-4 text-center">36-38</td>
                  <td className="py-2 px-4 text-center">42-44</td>
                  <td className="py-2 px-4 text-center">18-19</td>
                </tr>
              </tbody>
            </table>
          </div>
          
          <div className="mt-6">
            <h4 className="font-medium mb-2">How to measure</h4>
            <ul className="list-disc pl-5 space-y-2 text-sm">
              <li><strong>Chest:</strong> Measure around the fullest part of your chest, keeping the measuring tape horizontal.</li>
              <li><strong>Waist:</strong> Measure around your natural waistline, keeping the tape comfortably loose.</li>
              <li><strong>Hip:</strong> Measure around the fullest part of your hips, about 8 inches below your waist.</li>
              <li><strong>Shoulder:</strong> Measure from the edge of one shoulder to the other.</li>
            </ul>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default SizeGuide;
