import { useState } from 'react';
import { Link } from 'wouter';
import { 
  Heart, 
  Ruler, 
  Plus, 
  Minus, 
  Star, 
  StarHalf, 
  Share2, 
  ShoppingBag,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import ProductCard from '@/components/ui/product-card';
import { Skeleton } from '@/components/ui/skeleton';
import { Product } from '@/types';

interface ProductDetailProps {
  product: Product;
  onSizeGuideClick: () => void;
  onQuickView: (product: Product) => void;
}

const ProductDetail = ({ product, onSizeGuideClick, onQuickView }: ProductDetailProps) => {
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0] || '');
  const [selectedColor, setSelectedColor] = useState<string>(product.colors[0]?.name || '');
  const [quantity, setQuantity] = useState(1);
  const [mainImage, setMainImage] = useState(product.images[0]);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [expandDescription, setExpandDescription] = useState(false);

  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Default userId for demo purposes - in a real app this would come from authentication
  const userId = 1;

  // Fetch related products (products in the same category)
  const { data: relatedProducts, isLoading: relatedLoading } = useQuery({
    queryKey: ['/api/products', { categoryId: product.categoryId, limit: 4 }],
    queryFn: async () => {
      const res = await fetch(`/api/products?categoryId=${product.categoryId}&limit=4`);
      if (!res.ok) throw new Error('Failed to fetch related products');
      return res.json();
    }
  });

  // Add to cart mutation
  const addToCartMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('POST', '/api/cart', {
        userId,
        productId: product.id,
        size: selectedSize,
        color: selectedColor,
        quantity
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      toast({
        title: "Added to bag",
        description: `${product.name} has been added to your shopping bag`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to add item to bag. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Toggle wishlist mutation
  const toggleWishlistMutation = useMutation({
    mutationFn: async () => {
      if (isWishlisted) {
        // This is simplified - normally you'd need the wishlist item ID
        return Promise.resolve();
      } else {
        return apiRequest('POST', '/api/wishlist', {
          userId,
          productId: product.id
        });
      }
    },
    onSuccess: () => {
      setIsWishlisted(!isWishlisted);
      queryClient.invalidateQueries({ queryKey: ['/api/wishlist'] });
      toast({
        title: isWishlisted ? "Removed from wishlist" : "Added to wishlist",
        description: `${product.name} has been ${isWishlisted ? 'removed from' : 'added to'} your wishlist`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update wishlist. Please try again.",
        variant: "destructive",
      });
    }
  });

  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };

  const increaseQuantity = () => {
    if (quantity < 10) {
      setQuantity(quantity + 1);
    }
  };

  const handleBuyNow = () => {
    addToCartMutation.mutate();
    // Navigate to checkout page
    window.location.href = '/checkout';
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col lg:flex-row -mx-4">
        {/* Product Images */}
        <div className="lg:w-1/2 px-4 mb-8 lg:mb-0">
          <div className="sticky top-24">
            <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4">
              {/* Thumbnails */}
              <div className="order-2 md:order-1 flex md:flex-col space-x-2 md:space-x-0 md:space-y-2">
                {product.images.map((image, index) => (
                  <button 
                    key={index}
                    className={`w-16 h-20 rounded-md overflow-hidden ${mainImage === image ? 'ring-2 ring-[#FF3F6C]' : 'ring-1 ring-gray-200'}`}
                    onClick={() => setMainImage(image)}
                  >
                    <img 
                      src={image} 
                      alt={`${product.name} - View ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
              
              {/* Main Image */}
              <div className="order-1 md:order-2 flex-1">
                <div className="rounded-lg overflow-hidden">
                  <img 
                    src={mainImage} 
                    alt={product.name}
                    className="w-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Product Info */}
        <div className="lg:w-1/2 px-4">
          <div>
            <h1 className="text-2xl font-bold text-[#3E4152]">{product.brand}</h1>
            <h2 className="text-xl text-[#696B79] mb-4">{product.name}</h2>
            
            <div className="flex items-center mb-6">
              <div className="bg-[#14CDA2] text-white text-sm font-medium px-2 py-1 rounded flex items-center mr-3">
                <span className="mr-1">4.3</span>
                <Star className="h-3 w-3 fill-white" />
              </div>
              <span className="text-sm text-[#696B79]">253 Ratings</span>
            </div>

            <Separator className="my-4" />
            
            <div className="flex items-center mb-6">
              <span className="text-2xl font-bold mr-3">₹{product.price.toLocaleString('en-IN')}</span>
              <span className="text-lg text-gray-500 line-through mr-3">₹{product.originalPrice.toLocaleString('en-IN')}</span>
              <span className="text-[#14CDA2] font-medium">({product.discount}% OFF)</span>
            </div>
            
            <div className="mb-6">
              <h3 className="font-semibold mb-2">Select Color</h3>
              <div className="flex items-center space-x-3 mb-4">
                {product.colors.map((color, index) => (
                  <button 
                    key={index}
                    className={`w-10 h-10 rounded-full flex items-center justify-center transition ${selectedColor === color.name ? 'ring-2 ring-[#FF3F6C] ring-offset-2' : ''}`}
                    style={{ backgroundColor: color.code }}
                    onClick={() => setSelectedColor(color.name)}
                    aria-label={`Select ${color.name} color`}
                  />
                ))}
              </div>
              
              <h3 className="font-semibold mb-2">Select Size</h3>
              <div className="flex items-center flex-wrap gap-3">
                {product.sizes.map((size, index) => (
                  <button 
                    key={index}
                    className={`min-w-12 h-12 px-3 border rounded-md flex items-center justify-center
                      ${selectedSize === size 
                        ? 'border-[#FF3F6C] bg-[#FF3F6C]/5 font-medium text-[#FF3F6C]' 
                        : 'hover:border-[#FF3F6C] transition-colors'}`}
                    onClick={() => setSelectedSize(size)}
                  >
                    {size}
                  </button>
                ))}
              </div>
              <button 
                className="text-sm text-[#FF3F6C] mt-2 hover:underline flex items-center" 
                onClick={onSizeGuideClick}
              >
                <Ruler className="mr-1 h-4 w-4" /> Size Guide
              </button>
            </div>
            
            <div className="mb-6">
              <h3 className="font-semibold mb-2">Quantity</h3>
              <div className="flex items-center">
                <button 
                  className="w-10 h-10 border border-gray-300 rounded-l flex items-center justify-center hover:bg-gray-100 transition-colors"
                  onClick={decreaseQuantity}
                  disabled={quantity <= 1}
                >
                  <Minus className="h-4 w-4" />
                </button>
                <input 
                  type="number" 
                  className="w-14 h-10 border-t border-b border-gray-300 text-center" 
                  value={quantity} 
                  min="1"
                  max="10"
                  readOnly
                />
                <button 
                  className="w-10 h-10 border border-gray-300 rounded-r flex items-center justify-center hover:bg-gray-100 transition-colors"
                  onClick={increaseQuantity}
                  disabled={quantity >= 10}
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>
            </div>
            
            <div className="flex space-x-4 mb-8">
              <Button 
                className="flex-1 bg-[#FF3F6C] text-white py-6 rounded font-medium hover:bg-[#FF3F6C]/90 transition-colors"
                onClick={() => addToCartMutation.mutate()}
                disabled={addToCartMutation.isPending || !selectedSize || !selectedColor}
              >
                <ShoppingBag className="mr-2 h-5 w-5" />
                {addToCartMutation.isPending ? 'ADDING...' : 'ADD TO BAG'}
              </Button>
              <Button 
                variant="outline"
                className={`px-6 py-6 rounded flex items-center justify-center
                  ${isWishlisted 
                    ? 'border-[#FF3F6C] text-[#FF3F6C]' 
                    : 'border-gray-300 hover:bg-gray-100 transition-colors'}`}
                onClick={() => toggleWishlistMutation.mutate()}
                disabled={toggleWishlistMutation.isPending}
              >
                <Heart className={`mr-2 h-5 w-5 ${isWishlisted ? 'fill-[#FF3F6C]' : ''}`} />
                WISHLIST
              </Button>
            </div>

            <Button
              className="w-full mb-8 bg-[#14CDA2] hover:bg-[#14CDA2]/90 text-white py-6 rounded font-medium"
              onClick={handleBuyNow}
              disabled={addToCartMutation.isPending || !selectedSize || !selectedColor}
            >
              BUY NOW
            </Button>
            
            <Separator className="my-6" />
            
            <div className="mb-6">
              <div 
                className="flex items-center justify-between cursor-pointer"
                onClick={() => setExpandDescription(!expandDescription)}
              >
                <h3 className="font-semibold text-lg">Product Details</h3>
                {expandDescription ? (
                  <ChevronUp className="h-5 w-5 text-[#696B79]" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-[#696B79]" />
                )}
              </div>
              
              {expandDescription && (
                <div className="mt-4 text-[#696B79]">
                  <p>{product.description}</p>
                  <ul className="mt-4 space-y-2 list-disc pl-5">
                    <li>Material: Premium quality fabric</li>
                    <li>Care Instructions: Machine wash cold</li>
                    <li>Country of Origin: India</li>
                  </ul>
                </div>
              )}
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg mb-6">
              <div className="flex items-center space-x-6">
                <div className="flex items-center">
                  <i className="fas fa-truck text-[#FF3F6C] mr-2"></i>
                  <span className="text-sm">Free Delivery</span>
                </div>
                <div className="flex items-center">
                  <i className="fas fa-undo-alt text-[#FF3F6C] mr-2"></i>
                  <span className="text-sm">30-Day Returns</span>
                </div>
                <div className="flex items-center">
                  <i className="fas fa-shield-alt text-[#FF3F6C] mr-2"></i>
                  <span className="text-sm">100% Authentic</span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <img src="https://img.icons8.com/color/48/null/verified-badge.png" className="w-6 h-6" alt="Genuine Product" />
                <span className="text-sm font-medium">100% Genuine Product</span>
              </div>
              <button className="flex items-center text-sm text-[#696B79] hover:text-[#FF3F6C]">
                <Share2 className="h-4 w-4 mr-1" />
                Share
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs Section */}
      <div className="mt-16">
        <Tabs defaultValue="details">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="details">Details</TabsTrigger>
            <TabsTrigger value="reviews">Reviews</TabsTrigger>
            <TabsTrigger value="shipping">Shipping & Returns</TabsTrigger>
          </TabsList>
          <TabsContent value="details" className="bg-white p-6 rounded-lg shadow-sm">
            <h3 className="text-lg font-semibold mb-4">Product Specifications</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium mb-2">Material & Care</h4>
                <ul className="list-disc pl-5 space-y-1 text-[#696B79]">
                  <li>Premium quality fabric</li>
                  <li>Machine wash cold</li>
                  <li>Do not bleach</li>
                  <li>Tumble dry low</li>
                  <li>Iron on low heat</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Specifications</h4>
                <ul className="space-y-2 text-[#696B79]">
                  <li><span className="font-medium">Brand:</span> {product.brand}</li>
                  <li><span className="font-medium">Country of Origin:</span> India</li>
                  <li><span className="font-medium">Return Policy:</span> 30 days easy return</li>
                </ul>
              </div>
            </div>
          </TabsContent>
          <TabsContent value="reviews" className="bg-white p-6 rounded-lg shadow-sm">
            <div className="flex flex-col md:flex-row">
              <div className="md:w-1/3 mb-6 md:mb-0 md:pr-8">
                <div className="text-center">
                  <div className="text-5xl font-bold mb-2">4.3</div>
                  <div className="flex justify-center mb-2">
                    {Array(4).fill(0).map((_, i) => (
                      <Star key={i} className="text-amber-400 fill-amber-400 h-5 w-5" />
                    ))}
                    <StarHalf className="text-amber-400 fill-amber-400 h-5 w-5" />
                  </div>
                  <div className="text-sm text-[#696B79]">Based on 253 ratings</div>
                </div>
                
                <div className="mt-6 space-y-2">
                  <div className="flex items-center">
                    <span className="w-8 text-sm text-[#696B79]">5★</span>
                    <div className="flex-1 ml-2 h-2 bg-gray-200 rounded-full">
                      <div className="h-full bg-green-500 rounded-full" style={{ width: '60%' }}></div>
                    </div>
                    <span className="w-8 text-right text-sm text-[#696B79]">60%</span>
                  </div>
                  <div className="flex items-center">
                    <span className="w-8 text-sm text-[#696B79]">4★</span>
                    <div className="flex-1 ml-2 h-2 bg-gray-200 rounded-full">
                      <div className="h-full bg-green-500 rounded-full" style={{ width: '25%' }}></div>
                    </div>
                    <span className="w-8 text-right text-sm text-[#696B79]">25%</span>
                  </div>
                  <div className="flex items-center">
                    <span className="w-8 text-sm text-[#696B79]">3★</span>
                    <div className="flex-1 ml-2 h-2 bg-gray-200 rounded-full">
                      <div className="h-full bg-yellow-500 rounded-full" style={{ width: '10%' }}></div>
                    </div>
                    <span className="w-8 text-right text-sm text-[#696B79]">10%</span>
                  </div>
                  <div className="flex items-center">
                    <span className="w-8 text-sm text-[#696B79]">2★</span>
                    <div className="flex-1 ml-2 h-2 bg-gray-200 rounded-full">
                      <div className="h-full bg-orange-500 rounded-full" style={{ width: '3%' }}></div>
                    </div>
                    <span className="w-8 text-right text-sm text-[#696B79]">3%</span>
                  </div>
                  <div className="flex items-center">
                    <span className="w-8 text-sm text-[#696B79]">1★</span>
                    <div className="flex-1 ml-2 h-2 bg-gray-200 rounded-full">
                      <div className="h-full bg-red-500 rounded-full" style={{ width: '2%' }}></div>
                    </div>
                    <span className="w-8 text-right text-sm text-[#696B79]">2%</span>
                  </div>
                </div>
              </div>
              
              <div className="md:w-2/3 md:border-l md:pl-8">
                <h3 className="text-lg font-semibold mb-4">Customer Reviews</h3>
                <div className="space-y-6">
                  <div className="pb-4 border-b">
                    <div className="flex items-center mb-2">
                      <div className="flex mr-2">
                        {Array(5).fill(0).map((_, i) => (
                          <Star key={i} className="text-amber-400 fill-amber-400 h-4 w-4" />
                        ))}
                      </div>
                      <span className="text-sm font-medium">Great product!</span>
                    </div>
                    <p className="text-sm text-[#696B79] mb-2">Perfect fit and excellent quality. Very happy with my purchase!</p>
                    <div className="text-xs text-[#696B79] flex items-center justify-between">
                      <span>Amit S. | 15 May, 2023</span>
                      <span className="text-[#3E4152]">Verified Purchase</span>
                    </div>
                  </div>
                  
                  <div className="pb-4 border-b">
                    <div className="flex items-center mb-2">
                      <div className="flex mr-2">
                        {Array(4).fill(0).map((_, i) => (
                          <Star key={i} className="text-amber-400 fill-amber-400 h-4 w-4" />
                        ))}
                      </div>
                      <span className="text-sm font-medium">Good but sizing runs large</span>
                    </div>
                    <p className="text-sm text-[#696B79] mb-2">The quality is good but the sizing runs a bit large. Order one size down.</p>
                    <div className="text-xs text-[#696B79] flex items-center justify-between">
                      <span>Priya M. | 2 May, 2023</span>
                      <span className="text-[#3E4152]">Verified Purchase</span>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex items-center mb-2">
                      <div className="flex mr-2">
                        {Array(5).fill(0).map((_, i) => (
                          <Star key={i} className="text-amber-400 fill-amber-400 h-4 w-4" />
                        ))}
                      </div>
                      <span className="text-sm font-medium">Excellent product and delivery</span>
                    </div>
                    <p className="text-sm text-[#696B79] mb-2">The color is exactly as shown in the pictures. Fast delivery and great packaging. Will buy again!</p>
                    <div className="text-xs text-[#696B79] flex items-center justify-between">
                      <span>Rohan K. | 28 April, 2023</span>
                      <span className="text-[#3E4152]">Verified Purchase</span>
                    </div>
                  </div>
                </div>
                
                <Button className="mt-6 bg-white text-[#FF3F6C] border border-[#FF3F6C] hover:bg-[#FF3F6C]/5">
                  View All Reviews
                </Button>
              </div>
            </div>
          </TabsContent>
          <TabsContent value="shipping" className="bg-white p-6 rounded-lg shadow-sm">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-2">Shipping Information</h3>
                <ul className="list-disc pl-5 space-y-1 text-[#696B79]">
                  <li>Free standard shipping on all orders above ₹999</li>
                  <li>Standard delivery: 4-5 business days</li>
                  <li>Express delivery (extra charges): 1-2 business days</li>
                  <li>We ship to all major cities and towns in India</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-2">Return Policy</h3>
                <ul className="list-disc pl-5 space-y-1 text-[#696B79]">
                  <li>Easy 30-day return policy</li>
                  <li>Returns are free for all orders</li>
                  <li>Products must be unused, unwashed and in original condition with all tags attached</li>
                  <li>For hygiene reasons, innerwear and certain accessories cannot be returned</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-2">Need Help?</h3>
                <p className="text-[#696B79]">
                  If you have any questions about shipping, delivery, or returns, please contact our customer service team:
                </p>
                <p className="text-[#696B79] mt-2">
                  <strong>Email:</strong> support@borcelle.com<br />
                  <strong>Phone:</strong> 1800-123-4567 (Monday to Saturday, 10 AM to 7 PM)
                </p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Related Products */}
      <div className="mt-16">
        <h2 className="text-2xl font-semibold mb-8">You May Also Like</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {relatedLoading ? (
            Array(4).fill(0).map((_, index) => (
              <div key={index}>
                <Skeleton className="w-full aspect-[3/4] rounded-md mb-3" />
                <Skeleton className="h-4 w-20 mb-2" />
                <Skeleton className="h-4 w-32 mb-2" />
                <Skeleton className="h-4 w-24" />
              </div>
            ))
          ) : (
            relatedProducts?.filter((p: Product) => p.id !== product.id)
              .slice(0, 4)
              .map((product: Product) => (
                <ProductCard 
                  key={product.id} 
                  product={product} 
                  onQuickView={onQuickView}
                />
              ))
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
