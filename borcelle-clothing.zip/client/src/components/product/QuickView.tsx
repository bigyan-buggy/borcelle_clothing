import { useState } from 'react';
import { X, Heart, Ruler, Plus, Minus } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Product } from '@/types';

interface QuickViewProps {
  isOpen: boolean;
  onClose: () => void;
  product: Product | null;
  onSizeGuideClick: () => void;
}

const QuickView = ({ isOpen, onClose, product, onSizeGuideClick }: QuickViewProps) => {
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState<string>('');
  const [isWishlisted, setIsWishlisted] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Default userId for demo purposes - in a real app this would come from authentication
  const userId = 1;

  // Reset state when product changes
  if (product && (!selectedSize || !selectedColor || !selectedImage)) {
    if (!selectedSize && product.sizes.length > 0) {
      setSelectedSize(product.sizes[0]);
    }
    if (!selectedColor && product.colors.length > 0) {
      setSelectedColor(product.colors[0].name);
    }
    if (!selectedImage && product.images.length > 0) {
      setSelectedImage(product.images[0]);
    }
  }

  // Reset all state when dialog closes
  const handleOpenChange = (open: boolean) => {
    if (!open) {
      onClose();
      setQuantity(1);
    }
  };

  // Add to cart mutation
  const addToCartMutation = useMutation({
    mutationFn: async () => {
      if (!product || !selectedSize || !selectedColor) {
        throw new Error('Please select a size and color');
      }
      
      return apiRequest('POST', '/api/cart', {
        userId,
        productId: product.id,
        size: selectedSize,
        color: selectedColor,
        quantity
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      toast({
        title: "Added to bag",
        description: `${product?.name} has been added to your shopping bag`,
      });
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add item to bag",
        variant: "destructive",
      });
    }
  });

  // Toggle wishlist mutation
  const toggleWishlistMutation = useMutation({
    mutationFn: async () => {
      if (!product) return;
      
      if (isWishlisted) {
        // This is simplified - normally you'd need the wishlist item ID
        return Promise.resolve();
      } else {
        return apiRequest('POST', '/api/wishlist', {
          userId,
          productId: product.id
        });
      }
    },
    onSuccess: () => {
      setIsWishlisted(!isWishlisted);
      queryClient.invalidateQueries({ queryKey: ['/api/wishlist'] });
      toast({
        title: isWishlisted ? "Removed from wishlist" : "Added to wishlist",
        description: `${product?.name} has been ${isWishlisted ? 'removed from' : 'added to'} your wishlist`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update wishlist. Please try again.",
        variant: "destructive",
      });
    }
  });

  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };

  const increaseQuantity = () => {
    if (quantity < 10) {
      setQuantity(quantity + 1);
    }
  };

  if (!product) return null;

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-4xl">
        <DialogHeader>
          <DialogTitle>Quick View</DialogTitle>
          <DialogClose className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground">
            <X className="h-4 w-4" />
            <span className="sr-only">Close</span>
          </DialogClose>
        </DialogHeader>
        
        <div className="flex flex-col md:flex-row">
          <div className="md:w-1/2 mb-6 md:mb-0 md:pr-6">
            <div className="aspect-[3/4] bg-gray-100 mb-4 rounded-lg overflow-hidden">
              <img 
                src={selectedImage} 
                alt={product.name} 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex space-x-2">
              {product.images.map((image, index) => (
                <button 
                  key={index}
                  className={`w-16 h-20 rounded-md bg-gray-100 overflow-hidden ${selectedImage === image ? 'border-2 border-[#FF3F6C]' : 'border border-gray-200'}`}
                  onClick={() => setSelectedImage(image)}
                >
                  <img 
                    src={image} 
                    alt={`Product Thumbnail ${index + 1}`} 
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          </div>
          
          <div className="md:w-1/2">
            <h3 className="font-medium text-[#3E4152] text-lg">{product.brand}</h3>
            <p className="text-xl font-semibold mb-2">{product.name}</p>
            <div className="flex items-center mb-4">
              <div className="text-amber-400 flex mr-2">
                {Array(5).fill(0).map((_, i) => (
                  <span key={i} className="text-amber-400">
                    <i className="fas fa-star"></i>
                  </span>
                ))}
              </div>
              <span className="text-sm text-[#696B79]">4.5 (120 reviews)</span>
            </div>
            
            <div className="flex items-center mb-6">
              <span className="text-2xl font-bold mr-3">₹{product.price.toLocaleString('en-IN')}</span>
              <span className="text-lg text-gray-500 line-through mr-3">₹{product.originalPrice.toLocaleString('en-IN')}</span>
              <span className="text-sm text-[#14CDA2] font-medium">{product.discount}% OFF</span>
            </div>
            
            <div className="mb-6">
              <h4 className="font-medium mb-2">Color</h4>
              <div className="flex items-center space-x-3 mb-4">
                {product.colors.map((color, index) => (
                  <button 
                    key={index}
                    className={`w-8 h-8 rounded-full flex items-center justify-center ${selectedColor === color.name ? 'ring-2 ring-[#FF3F6C] ring-offset-2' : ''}`}
                    style={{ backgroundColor: color.code }}
                    onClick={() => setSelectedColor(color.name)}
                    aria-label={`Select ${color.name} color`}
                  />
                ))}
              </div>
              
              <h4 className="font-medium mb-2">Size</h4>
              <div className="flex items-center space-x-3">
                {product.sizes.map((size, index) => (
                  <button 
                    key={index}
                    className={`w-10 h-10 border rounded-full flex items-center justify-center
                      ${selectedSize === size 
                        ? 'border-[#FF3F6C] bg-[#FF3F6C]/5 font-medium text-[#FF3F6C]' 
                        : 'hover:border-[#FF3F6C] transition-colors'}`}
                    onClick={() => setSelectedSize(size)}
                  >
                    {size}
                  </button>
                ))}
              </div>
              <button 
                className="text-sm text-[#FF3F6C] mt-2 hover:underline flex items-center" 
                onClick={onSizeGuideClick}
              >
                <Ruler className="mr-1 h-4 w-4" /> Size Guide
              </button>
            </div>
            
            <div className="mb-6">
              <h4 className="font-medium mb-2">Quantity</h4>
              <div className="flex items-center">
                <button 
                  className="w-8 h-8 border border-gray-300 rounded-l flex items-center justify-center hover:bg-gray-100 transition-colors"
                  onClick={decreaseQuantity}
                  disabled={quantity <= 1}
                >
                  <Minus className="h-3 w-3" />
                </button>
                <input 
                  type="number" 
                  className="w-12 h-8 border-t border-b border-gray-300 text-center" 
                  value={quantity} 
                  min="1"
                  max="10"
                  readOnly
                />
                <button 
                  className="w-8 h-8 border border-gray-300 rounded-r flex items-center justify-center hover:bg-gray-100 transition-colors"
                  onClick={increaseQuantity}
                  disabled={quantity >= 10}
                >
                  <Plus className="h-3 w-3" />
                </button>
              </div>
            </div>
            
            <div className="flex space-x-4 mb-6">
              <Button 
                className="flex-1 bg-[#FF3F6C] text-white py-3 rounded font-medium hover:bg-[#FF3F6C]/90 transition-colors"
                onClick={() => addToCartMutation.mutate()}
                disabled={addToCartMutation.isPending || !selectedSize || !selectedColor}
              >
                {addToCartMutation.isPending ? 'ADDING...' : 'ADD TO BAG'}
              </Button>
              <Button 
                variant="outline"
                className={`w-12 h-12 rounded flex items-center justify-center
                  ${isWishlisted 
                    ? 'border-[#FF3F6C] text-[#FF3F6C]' 
                    : 'border-gray-300 hover:bg-gray-100 transition-colors'}`}
                onClick={() => toggleWishlistMutation.mutate()}
                disabled={toggleWishlistMutation.isPending}
              >
                <Heart className={isWishlisted ? 'fill-[#FF3F6C]' : ''} />
              </Button>
            </div>
            
            <div className="text-sm text-[#696B79] space-y-2">
              <p>Free shipping on orders above ₹999</p>
              <p>Easy 30 days return policy</p>
              <p>COD available</p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default QuickView;
