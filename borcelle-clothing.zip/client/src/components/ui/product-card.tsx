import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { calculateDiscount } from '@/lib/utils';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Product } from '@/types';

interface ProductCardProps {
  product: Product;
  onQuickView?: (product: Product) => void;
  userId?: number;
}

const ProductCard = ({ product, onQuickView, userId = 1 }: ProductCardProps) => {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isWishlisted, setIsWishlisted] = useState(false);

  // Add to cart mutation
  const addToCartMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('POST', '/api/cart', {
        userId,
        productId: product.id,
        size: product.sizes[0], // Default to first size
        color: product.colors[0].name, // Default to first color
        quantity: 1
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      toast({
        title: "Added to bag",
        description: `${product.name} has been added to your shopping bag`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to add item to bag. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Toggle wishlist mutation
  const toggleWishlistMutation = useMutation({
    mutationFn: async () => {
      if (isWishlisted) {
        // Would need the wishlist item ID in a real implementation
        // For now we'll just toggle the state
        return Promise.resolve();
      } else {
        return apiRequest('POST', '/api/wishlist', {
          userId,
          productId: product.id
        });
      }
    },
    onSuccess: () => {
      setIsWishlisted(!isWishlisted);
      queryClient.invalidateQueries({ queryKey: ['/api/wishlist'] });
      toast({
        title: isWishlisted ? "Removed from wishlist" : "Added to wishlist",
        description: `${product.name} has been ${isWishlisted ? 'removed from' : 'added to'} your wishlist`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update wishlist. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleAddToBag = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCartMutation.mutate();
  };

  const handleToggleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleWishlistMutation.mutate();
  };

  const handleQuickView = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (onQuickView) {
      onQuickView(product);
    }
  };

  return (
    <div className="group relative">
      <div onClick={() => navigate(`/product/${product.slug}`)} className="cursor-pointer block">
        <div className="relative overflow-hidden rounded-md mb-3">
          <div className="aspect-[3/4] bg-gray-100">
            <img 
              src={product.images[0]} 
              alt={product.name} 
              className="w-full h-full object-cover"
              loading="lazy"
              onDoubleClick={handleQuickView}
            />
          </div>
          
          {/* Wishlist button */}
          <button 
            className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/80 backdrop-blur-sm flex items-center justify-center hover:bg-white transition-colors"
            aria-label={isWishlisted ? "Remove from wishlist" : "Add to wishlist"}
            onClick={handleToggleWishlist}
          >
            <Heart 
              size={16} 
              className={isWishlisted ? 'fill-[#FF3F6C] text-[#FF3F6C]' : 'text-[#282C3F]'} 
            />
          </button>
          
          {/* CTA Button shown on hover */}
          <div className="absolute bottom-0 left-0 right-0 bg-white p-2 translate-y-full group-hover:translate-y-0 transition-transform duration-300 flex">
            <Button 
              className="w-full bg-[#FF3F6C] text-white py-2 rounded font-medium text-sm hover:bg-[#FF3F6C]/90 transition-colors"
              onClick={handleAddToBag}
              disabled={addToCartMutation.isPending}
            >
              {addToCartMutation.isPending ? 'ADDING...' : 'ADD TO BAG'}
            </Button>
          </div>
          
          {/* Tags */}
          {(product.isNew || product.isTrending || product.isBestSeller) && (
            <div className="absolute top-3 left-3">
              {product.isNew && (
                <span className="bg-[#FFC900] text-[#282C3F] text-xs font-medium px-2 py-1 rounded">NEW</span>
              )}
              {product.isTrending && (
                <span className="bg-[#FF3F6C] text-white text-xs font-medium px-2 py-1 rounded ml-1">TRENDING</span>
              )}
              {product.isBestSeller && (
                <span className="bg-[#FF3F6C] text-white text-xs font-medium px-2 py-1 rounded ml-1">BESTSELLER</span>
              )}
            </div>
          )}
        </div>
        
        <div>
          <h3 className="font-medium text-[#3E4152]">{product.brand}</h3>
          <p className="text-sm text-[#696B79] truncate">{product.name}</p>
          <div className="flex items-center mt-1">
            <span className="font-semibold mr-2">₹{product.price.toLocaleString('en-IN')}</span>
            <span className="text-sm text-gray-500 line-through mr-2">₹{product.originalPrice.toLocaleString('en-IN')}</span>
            <span className="text-xs text-[#14CDA2] font-medium">{product.discount}% OFF</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
