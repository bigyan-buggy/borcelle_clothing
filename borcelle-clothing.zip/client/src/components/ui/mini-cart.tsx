import { useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { formatPrice } from '@/lib/utils';

interface MiniCartProps {
  isOpen: boolean;
  onClose: () => void;
}

const MiniCart = ({ isOpen, onClose }: MiniCartProps) => {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();

  // Fetch cart items
  const { data: cartItems = [], isLoading } = useQuery({
    queryKey: ['/api/cart', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      const res = await fetch(`/api/cart?userId=${user.id}`);
      if (!res.ok) throw new Error('Failed to fetch cart items');
      return res.json();
    },
    enabled: isOpen && !!user?.id,
  });

  // Remove from cart mutation
  const removeFromCartMutation = useMutation({
    mutationFn: async (cartItemId: number) => {
      return apiRequest('DELETE', `/api/cart/${cartItemId}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      toast({
        title: "Item removed",
        description: "Item has been removed from your shopping bag",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to remove item. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Update quantity mutation
  const updateQuantityMutation = useMutation({
    mutationFn: async ({ id, quantity }: { id: number; quantity: number }) => {
      return apiRequest('PATCH', `/api/cart/${id}`, { quantity });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update quantity. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Calculate cart totals
  const subtotal = cartItems.reduce(
    (total: number, item: any) => total + (item.product.price * item.quantity), 
    0
  );
  const shippingFee = subtotal >= 999 ? 0 : 99;
  const total = subtotal + shippingFee;

  // Handle closing the cart
  const handleClose = () => {
    onClose();
  };

  // Handle checkout
  const handleCheckout = () => {
    navigate('/checkout');
    onClose();
  };

  // Handle view bag
  const handleViewBag = () => {
    navigate('/cart');
    onClose();
  };

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isOpen, onClose]);

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40"
          onClick={handleClose}
        ></div>
      )}

      {/* Mini Cart Drawer */}
      <div 
        className={`fixed right-0 top-0 h-full w-96 max-w-full bg-white shadow-lg transform transition-transform duration-300 z-50 ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}
      >
        <div className="h-full flex flex-col">
          <div className="p-4 border-b flex items-center justify-between">
            <h2 className="text-lg font-semibold">
              Your Shopping Bag ({cartItems.length})
            </h2>
            <button 
              className="text-gray-500 hover:text-gray-700" 
              onClick={handleClose}
            >
              <i className="fas fa-times"></i>
            </button>
          </div>
          
          <div className="flex-grow overflow-auto p-4">
            {isLoading ? (
              <div className="flex items-center justify-center h-40">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#FF3F6C]"></div>
              </div>
            ) : cartItems.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-40 text-center">
                <div className="text-gray-400 text-6xl mb-4">
                  <i className="fas fa-shopping-bag"></i>
                </div>
                <p className="text-lg font-medium mb-2">Your bag is empty</p>
                <p className="text-sm text-gray-500 mb-6">Add items to your shopping bag to checkout</p>
                <Button 
                  onClick={() => { navigate('/products'); onClose(); }}
                  className="bg-[#FF3F6C] hover:bg-[#FF3F6C]/90 text-white"
                >
                  CONTINUE SHOPPING
                </Button>
              </div>
            ) : (
              cartItems.map((item: any) => (
                <div key={item.id} className="flex mb-6 pb-6 border-b">
                  <div className="w-20 h-24 bg-gray-100 rounded overflow-hidden">
                    <img 
                      src={item.product.images[0]} 
                      alt={item.product.name} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="ml-4 flex-grow">
                    <h3 className="font-medium">{item.product.brand}</h3>
                    <p className="text-sm text-[#696B79] mb-2">{item.product.name}</p>
                    <div className="flex items-center mb-2">
                      <span className="text-xs text-gray-500">Size: {item.size}</span>
                      <span className="text-xs text-gray-500 ml-4">
                        Qty: 
                        <select 
                          className="ml-1 border-none bg-transparent" 
                          value={item.quantity}
                          onChange={(e) => updateQuantityMutation.mutate({ 
                            id: item.id, 
                            quantity: Number(e.target.value) 
                          })}
                        >
                          {[1, 2, 3, 4, 5].map(num => (
                            <option key={num} value={num}>{num}</option>
                          ))}
                        </select>
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <span className="font-semibold mr-2">₹{item.product.price.toLocaleString('en-IN')}</span>
                        <span className="text-xs text-gray-500 line-through">₹{item.product.originalPrice.toLocaleString('en-IN')}</span>
                      </div>
                      <button 
                        className="text-sm text-gray-500 hover:text-[#FF3F6C] transition-colors"
                        onClick={() => removeFromCartMutation.mutate(item.id)}
                        disabled={removeFromCartMutation.isPending}
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
          
          {cartItems.length > 0 && (
            <div className="bg-gray-50 p-4">
              <div className="mb-4">
                <div className="flex justify-between mb-2">
                  <span className="text-[#696B79]">Subtotal</span>
                  <span>₹{subtotal.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-[#696B79]">Shipping</span>
                  <span>{shippingFee === 0 ? 'FREE' : `₹${shippingFee}`}</span>
                </div>
                <Separator className="my-2" />
                <div className="flex justify-between font-medium">
                  <span>Total</span>
                  <span>₹{total.toLocaleString('en-IN')}</span>
                </div>
              </div>
              
              <Button 
                className="w-full bg-[#FF3F6C] text-white py-3 rounded font-medium hover:bg-[#FF3F6C]/90 transition-colors"
                onClick={handleCheckout}
              >
                CHECKOUT
              </Button>
              <Button 
                variant="outline"
                className="w-full mt-3 border border-[#FF3F6C] text-[#FF3F6C] py-3 rounded font-medium hover:bg-[#FF3F6C]/5 transition-colors"
                onClick={handleViewBag}
              >
                VIEW BAG
              </Button>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default MiniCart;
