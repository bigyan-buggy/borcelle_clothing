import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useIsMobile as useMobile } from '@/hooks/use-mobile';
import { useAuth } from '@/hooks/use-auth';
import { Search, User, Heart, ShoppingBag, Menu, X, LogOut, Settings } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import logoImage from "@assets/nav bar logo.png";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface HeaderProps {
  onCartClick: () => void;
}

const Header = ({ onCartClick }: HeaderProps) => {
  const { user, logoutMutation } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [location, navigate] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const isMobile = useMobile();
  const { toast } = useToast();
  
  // Fetch cart items to get count
  const { data: cartItems = [] } = useQuery({
    queryKey: ['/api/cart', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      const res = await fetch(`/api/cart?userId=${user.id}`);
      if (!res.ok) return [];
      return res.json();
    }
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products?search=${encodeURIComponent(searchQuery)}`);
      toast({
        title: "Searching",
        description: `Showing results for "${searchQuery}"`,
      });
    }
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const navItems = [
    { label: 'MEN', path: '/products/mens-fashion' },
    { label: 'WOMEN', path: '/products/womens-fashion' },
    { label: 'KIDS', path: '/products/kids-fashion' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <img src={logoImage} alt="Borcelle Clothing" className="h-16 my-2 px-4" />
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            {navItems.map((item, index) => (
              <Link key={index} href={item.path} className="font-medium hover:text-[#FF3F6C] transition-colors">
                {item.label}
              </Link>
            ))}
          </nav>

          {/* Search Bar */}
          <div className="hidden md:flex flex-1 mx-8 relative">
            <form onSubmit={handleSearch} className="w-full">
              <Input
                type="text"
                placeholder="Search for products, brands and more"
                className="w-full px-4 py-2 rounded-md bg-[#F5F5F6] focus:outline-none focus:ring-1 focus:ring-[#FF3F6C] text-sm"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Button 
                type="submit"
                variant="ghost" 
                size="icon" 
                className="absolute right-1 top-1/2 -translate-y-1/2 text-[#696B79]"
                aria-label="Search"
              >
                <Search size={18} />
              </Button>
            </form>
          </div>

          {/* Action Icons */}
          <div className="flex items-center space-x-6">
            {user ? (
              // User is logged in
              <div className="hidden md:block">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <div className="flex flex-col items-center group cursor-pointer">
                      <User className="h-5 w-5 group-hover:text-[#FF3F6C] transition-colors" />
                      <span className="text-xs mt-1 group-hover:text-[#FF3F6C] transition-colors">Profile</span>
                    </div>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <DropdownMenuLabel>My Account</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => navigate('/profile')}>
                      <User className="mr-2 h-4 w-4" />
                      <span>Profile</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate('/settings')}>
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Settings</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                      onClick={() => logoutMutation.mutate()}
                      disabled={logoutMutation.isPending}
                    >
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>{logoutMutation.isPending ? "Logging out..." : "Logout"}</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            ) : (
              // User is not logged in
              <Link href="/auth" className="hidden md:flex flex-col items-center group">
                <User className="h-5 w-5 group-hover:text-[#FF3F6C] transition-colors" />
                <span className="text-xs mt-1 group-hover:text-[#FF3F6C] transition-colors">Login</span>
              </Link>
            )}
            
            <Link href="/wishlist" className="hidden md:flex flex-col items-center group">
              <Heart className="h-5 w-5 group-hover:text-[#FF3F6C] transition-colors" />
              <span className="text-xs mt-1 group-hover:text-[#FF3F6C] transition-colors">Wishlist</span>
            </Link>
            
            <button 
              onClick={onCartClick}
              className="flex flex-col items-center group"
            >
              <div className="relative">
                <ShoppingBag className="h-5 w-5 group-hover:text-[#FF3F6C] transition-colors" />
                {cartItems.length > 0 && (
                  <span className="absolute -top-2 -right-2 bg-[#FF3F6C] text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">
                    {cartItems.length}
                  </span>
                )}
              </div>
              <span className="text-xs mt-1 group-hover:text-[#FF3F6C] transition-colors">Bag</span>
            </button>
            
            <button 
              className="md:hidden text-xl" 
              onClick={toggleMobileMenu}
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Search */}
      <div className="md:hidden px-4 pb-3">
        <form onSubmit={handleSearch} className="relative">
          <Input
            type="text"
            placeholder="Search for products, brands and more"
            className="w-full px-4 py-2 rounded-md bg-[#F5F5F6] focus:outline-none focus:ring-1 focus:ring-[#FF3F6C] text-sm"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <Button 
            type="submit"
            variant="ghost" 
            size="icon" 
            className="absolute right-1 top-1/2 -translate-y-1/2 text-[#696B79]"
            aria-label="Search"
          >
            <Search size={18} />
          </Button>
        </form>
      </div>

      {/* Mobile Navigation */}
      {isMobileMenuOpen && (
        <div className="px-4 py-2 bg-[#F5F5F6] md:hidden">
          <div className="flex flex-col space-y-4">
            {navItems.map((item, index) => (
              <Link 
                key={index} 
                href={item.path} 
                className="font-medium hover:text-[#FF3F6C] transition-colors"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {item.label}
              </Link>
            ))}
            <div className="border-t border-gray-200 pt-3 space-y-3">
              {user ? (
                // Logged in UI
                <>
                  <div className="flex items-center justify-between">
                    <div className="text-sm font-medium">
                      Logged in as <span className="text-[#FF3F6C]">{user.username}</span>
                    </div>
                  </div>
                  <div className="flex flex-col space-y-3">
                    <Link 
                      href="/profile" 
                      className="flex items-center"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      <User className="mr-2 h-4 w-4" />
                      <span>Profile</span>
                    </Link>
                    <Link 
                      href="/settings" 
                      className="flex items-center"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Settings</span>
                    </Link>
                    <Link 
                      href="/wishlist" 
                      className="flex items-center"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      <Heart className="mr-2 h-4 w-4" />
                      <span>Wishlist</span>
                    </Link>
                    <button 
                      className="flex items-center text-left text-red-500" 
                      onClick={() => {
                        logoutMutation.mutate();
                        setIsMobileMenuOpen(false);
                      }}
                      disabled={logoutMutation.isPending}
                    >
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>{logoutMutation.isPending ? "Logging out..." : "Logout"}</span>
                    </button>
                  </div>
                </>
              ) : (
                // Not logged in UI
                <div className="flex flex-col space-y-3">
                  <Link 
                    href="/auth" 
                    className="flex items-center"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <User className="mr-2 h-4 w-4" />
                    <span>Login / Register</span>
                  </Link>
                  <Link 
                    href="/wishlist" 
                    className="flex items-center"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <Heart className="mr-2 h-4 w-4" />
                    <span>Wishlist</span>
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
