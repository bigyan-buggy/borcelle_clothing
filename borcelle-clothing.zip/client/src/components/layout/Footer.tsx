import { Link } from 'wouter';
import { Facebook, Instagram, Youtube, Twitter, CreditCard, Repeat, Truck, Apple } from 'lucide-react';
import logoPath from "@assets/nav bar logo.png";

const Footer = () => {
  return (
    <footer className="bg-[#282C3F] text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="text-lg font-bold mb-4">ONLINE SHOPPING</h3>
            <ul className="space-y-2">
              <li><Link href="/products/mens-fashion" className="text-gray-300 hover:text-white transition-colors">Men</Link></li>
              <li><Link href="/products/womens-fashion" className="text-gray-300 hover:text-white transition-colors">Women</Link></li>
              <li><Link href="/products/kids-fashion" className="text-gray-300 hover:text-white transition-colors">Kids</Link></li>
              <li><Link href="/products/home-living" className="text-gray-300 hover:text-white transition-colors">Home & Living</Link></li>
              <li><Link href="/products/beauty" className="text-gray-300 hover:text-white transition-colors">Beauty</Link></li>
              <li><Link href="/gift-cards" className="text-gray-300 hover:text-white transition-colors">Gift Cards</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">CUSTOMER POLICIES</h3>
            <ul className="space-y-2">
              <li><Link href="/contact" className="text-gray-300 hover:text-white transition-colors">Contact Us</Link></li>
              <li><Link href="/faq" className="text-gray-300 hover:text-white transition-colors">FAQ</Link></li>
              <li><Link href="/terms" className="text-gray-300 hover:text-white transition-colors">T&C</Link></li>
              <li><Link href="/terms-of-use" className="text-gray-300 hover:text-white transition-colors">Terms Of Use</Link></li>
              <li><Link href="/track-orders" className="text-gray-300 hover:text-white transition-colors">Track Orders</Link></li>
              <li><Link href="/shipping" className="text-gray-300 hover:text-white transition-colors">Shipping</Link></li>
              <li><Link href="/cancellation" className="text-gray-300 hover:text-white transition-colors">Cancellation</Link></li>
              <li><Link href="/returns" className="text-gray-300 hover:text-white transition-colors">Returns</Link></li>
              <li><Link href="/privacy" className="text-gray-300 hover:text-white transition-colors">Privacy Policy</Link></li>
            </ul>
          </div>
          
          <div>
            {/* Brand Logo and Info */}
            <div className="mb-6">
              <div className="bg-white p-4 rounded-lg mb-3 inline-block">
                <img 
                  src={logoPath} 
                  alt="Borcelle Clothing" 
                  className="h-14 w-auto"
                />
              </div>
              <p className="text-gray-300 text-sm max-w-xs">Borcelle Clothing - Your premium fashion destination for the latest trends and timeless classics.</p>
            </div>
            
            <h3 className="text-lg font-bold mb-4">EXPERIENCE APP ON MOBILE</h3>
            <div className="flex space-x-4 mb-4">
              <a href="#" className="bg-black p-2 rounded-lg flex items-center hover:bg-gray-900 transition-colors border border-gray-700">
                <svg className="h-7 w-7 mr-2 text-white" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.0754 12.9992C17.0672 11.1572 18.1487 9.88767 20.332 8.66689C19.1776 7.05058 17.4219 6.1759 15.2498 6.02239C13.194 5.87411 10.9652 7.24475 10.2261 7.24475C9.44418 7.24475 7.50394 6.07497 5.89437 6.07497C3.03229 6.12392 0 8.39867 0 13.0365C0 14.5419 0.275319 16.1016 0.826097 17.7128C1.55769 19.8733 3.99522 24.0805 6.55411 23.9957C7.89296 23.958 8.86666 23.0304 10.6015 23.0304C12.2902 23.0304 13.194 23.9957 14.6756 23.9957C17.2617 23.958 19.4815 20.1544 20.171 18.0019C16.7663 16.3968 17.0754 13.0942 17.0754 12.9992ZM13.9825 4.08149C15.7797 2.01058 15.599 0.12351 15.5582 0C14.0144 0.0816822 12.2232 1.02977 11.2024 2.22415C10.0765 3.3467 9.47664 4.77635 9.60298 6.0073C11.2859 6.13641 12.8229 5.2664 13.9825 4.08149Z" />
                </svg>
                <div>
                  <p className="text-xs text-gray-400">Download on the</p>
                  <p className="text-sm font-medium">App Store</p>
                </div>
              </a>
              <a href="#" className="bg-black p-2 rounded-lg flex items-center hover:bg-gray-900 transition-colors border border-gray-700">
                <svg className="h-7 w-7 mr-2 text-white" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M1.35112 0.214401C1.18298 0.391122 1.09891 0.594242 1.09891 0.826602V23.1477C1.09891 23.3801 1.18298 23.5832 1.35112 23.7599L1.41503 23.8222L13.4699 11.8456V11.7661V11.6866L1.41503 -0.290761L1.35112 0.214401Z" fill="#00DC84"/>
                  <path d="M17.5778 15.9294L13.4697 11.8456V11.7661V11.6866L17.5778 7.60278L17.657 7.64465L22.506 10.3189C23.8232 11.0637 23.8232 12.4686 22.506 13.2133L17.657 15.8875L17.5778 15.9294Z" fill="#FFBC00"/>
                  <path d="M17.6571 15.8875L13.4698 11.7661L1.35107 23.7599C1.80317 24.1926 2.50296 24.2463 3.28937 23.8136L17.6571 15.8875Z" fill="#F1434B"/>
                  <path d="M17.6571 7.64465L3.28937 -0.281856C2.50296 -0.714559 1.80317 -0.660851 1.35107 -0.228148L13.4698 11.7661L17.6571 7.64465Z" fill="#2591FA"/>
                </svg>
                <div>
                  <p className="text-xs text-gray-400">GET IT ON</p>
                  <p className="text-sm font-medium">Google Play</p>
                </div>
              </a>
            </div>
            
            <h3 className="text-lg font-bold mb-4">KEEP IN TOUCH</h3>
            <div className="flex space-x-4">
              <a href="#" className="bg-blue-600 w-9 h-9 rounded-full flex items-center justify-center hover:bg-blue-700 transition-colors">
                <Facebook size={16} />
              </a>
              <a href="#" className="bg-pink-600 w-9 h-9 rounded-full flex items-center justify-center hover:bg-pink-700 transition-colors">
                <Instagram size={16} />
              </a>
              <a href="#" className="bg-red-600 w-9 h-9 rounded-full flex items-center justify-center hover:bg-red-700 transition-colors">
                <Youtube size={16} />
              </a>
              <a href="#" className="bg-blue-400 w-9 h-9 rounded-full flex items-center justify-center hover:bg-blue-500 transition-colors">
                <Twitter size={16} />
              </a>
            </div>
          </div>
          
          <div>
            <div className="flex items-center mb-4">
              <div className="w-16 h-16 mr-4 bg-white/10 rounded-full flex items-center justify-center">
                <CreditCard size={24} className="text-[#FF3F6C]" />
              </div>
              <div>
                <h4 className="font-medium">100% ORIGINAL</h4>
                <p className="text-sm text-gray-300">guarantee for all products</p>
              </div>
            </div>
            
            <div className="flex items-center mb-4">
              <div className="w-16 h-16 mr-4 bg-white/10 rounded-full flex items-center justify-center">
                <Repeat size={24} className="text-[#FF3F6C]" />
              </div>
              <div>
                <h4 className="font-medium">RETURN POLICY</h4>
                <p className="text-sm text-gray-300">within 30 days of receiving</p>
              </div>
            </div>
            
            <div className="flex items-center">
              <div className="w-16 h-16 mr-4 bg-white/10 rounded-full flex items-center justify-center">
                <Truck size={24} className="text-[#FF3F6C]" />
              </div>
              <div>
                <h4 className="font-medium">FREE DELIVERY</h4>
                <p className="text-sm text-gray-300">on orders above ₹999</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-700 pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm mb-4 md:mb-0">© 2024 Borcelle Clothing. All rights reserved.</p>
            <div className="flex items-center space-x-4">
              <img src="https://img.icons8.com/color/48/null/visa.png" alt="Visa" className="h-8" />
              <img src="https://img.icons8.com/color/48/null/mastercard.png" alt="Mastercard" className="h-8" />
              <img src="https://img.icons8.com/color/48/null/amex.png" alt="American Express" className="h-8" />
              <img src="https://img.icons8.com/color/48/null/paypal.png" alt="PayPal" className="h-8" />
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
