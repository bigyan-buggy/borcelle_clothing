import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

const DealsSection = () => {
  return (
    <section className="py-12 bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold mb-3">FLASH SALE</h2>
          <p className="text-lg opacity-90">Grab these amazing deals before they're gone!</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 flex flex-col items-center text-center">
            <span className="text-4xl font-bold mb-2">50%</span>
            <h3 className="text-xl font-semibold mb-4">OFF</h3>
            <p className="mb-4 opacity-90">On all summer collection</p>
            <Link href="/products?discount=50">
              <Button className="px-6 py-2 bg-white text-purple-700 rounded-md font-medium hover:bg-gray-100 transition-colors">
                Shop Now
              </Button>
            </Link>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 flex flex-col items-center text-center">
            <span className="text-4xl font-bold mb-2">BUY 1</span>
            <h3 className="text-xl font-semibold mb-4">GET 1 FREE</h3>
            <p className="mb-4 opacity-90">On selected items</p>
            <Link href="/products?promotion=buy1get1">
              <Button className="px-6 py-2 bg-white text-purple-700 rounded-md font-medium hover:bg-gray-100 transition-colors">
                Shop Now
              </Button>
            </Link>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 flex flex-col items-center text-center">
            <span className="text-4xl font-bold mb-2">₹500</span>
            <h3 className="text-xl font-semibold mb-4">OFF</h3>
            <p className="mb-4 opacity-90">On orders above ₹2,999</p>
            <Link href="/products?minOrder=2999">
              <Button className="px-6 py-2 bg-white text-purple-700 rounded-md font-medium hover:bg-gray-100 transition-colors">
                Shop Now
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DealsSection;
