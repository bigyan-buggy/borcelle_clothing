import { Link } from 'wouter';

const brands = [
  { name: 'NIKE', slug: 'nike' },
  { name: 'ADIDAS', slug: 'adidas' },
  { name: 'PUMA', slug: 'puma' },
  { name: 'LEVIS', slug: 'levis' },
  { name: 'FOSSIL', slug: 'fossil' },
  { name: 'H&M', slug: 'h-and-m' }
];

const BrandsSection = () => {
  return (
    <section className="py-12 bg-[#F5F5F6]">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-semibold mb-8 text-center">Top Brands</h2>
        <div className="grid grid-cols-3 md:grid-cols-6 gap-4">
          {brands.map((brand, index) => (
            <Link 
              key={index} 
              href={`/products?brand=${brand.slug}`}
              className="bg-white rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow flex items-center justify-center"
            >
              <span className="font-bold text-lg text-[#3E4152]">{brand.name}</span>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BrandsSection;
