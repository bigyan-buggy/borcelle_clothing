import { Star, StarHalf } from 'lucide-react';

const testimonials = [
  {
    rating: 5,
    text: "Absolutely love the collection at Borcelle. The clothes are stylish, comfortable and affordable. The delivery was prompt and the packaging was great!",
    name: "Riya Singh",
    initials: "RS"
  },
  {
    rating: 4.5,
    text: "The quality of the clothes is exceptional. I've been shopping here for over a year now and have never been disappointed. Great customer service too!",
    name: "Arun Kumar",
    initials: "AK"
  },
  {
    rating: 5,
    text: "Fast delivery and easy returns process. The size guide is accurate and helpful. Will definitely shop here again and recommend to friends!",
    name: "Neha Patel",
    initials: "NP"
  }
];

const TestimonialsSection = () => {
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`star-${i}`} className="text-amber-400 fill-amber-400" size={16} />);
    }
    
    if (hasHalfStar) {
      stars.push(<StarHalf key="half-star" className="text-amber-400 fill-amber-400" size={16} />);
    }
    
    return stars;
  };

  return (
    <section className="py-12 bg-gradient-to-r from-slate-100 to-blue-50">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-semibold mb-10 text-center">What Our Customers Say</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex items-center mb-4">
                <div className="text-amber-400 flex">
                  {renderStars(testimonial.rating)}
                </div>
                <span className="ml-2 text-sm font-medium">{testimonial.rating.toFixed(1)}</span>
              </div>
              <p className="text-gray-600 mb-4">"{testimonial.text}"</p>
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-500">
                  <span className="font-medium">{testimonial.initials}</span>
                </div>
                <div className="ml-3">
                  <p className="font-medium text-[#282C3F]">{testimonial.name}</p>
                  <p className="text-xs text-[#696B79]">Verified Buyer</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
