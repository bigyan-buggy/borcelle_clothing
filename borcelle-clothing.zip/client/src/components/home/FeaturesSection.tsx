import { Truck, RotateCcw, Shield, Headphones } from 'lucide-react';

const features = [
  {
    icon: <Truck className="text-[#FF3F6C] text-xl" />,
    title: "Free Shipping",
    description: "On orders above ₹999"
  },
  {
    icon: <RotateCcw className="text-[#FF3F6C] text-xl" />,
    title: "Easy Returns",
    description: "30-day return policy"
  },
  {
    icon: <Shield className="text-[#FF3F6C] text-xl" />,
    title: "Secure Payment",
    description: "Multiple payment options"
  },
  {
    icon: <Headphones className="text-[#FF3F6C] text-xl" />,
    title: "24/7 Support",
    description: "Customer service excellence"
  }
];

const FeaturesSection = () => {
  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div key={index} className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-[#FF3F6C]/10 flex items-center justify-center">
                {feature.icon}
              </div>
              <h3 className="font-medium mb-2">{feature.title}</h3>
              <p className="text-sm text-[#696B79]">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
