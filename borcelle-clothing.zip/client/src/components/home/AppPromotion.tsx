import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

const AppPromotion = () => {
  return (
    <section className="bg-[#282C3F] text-white py-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="mb-6 md:mb-0 md:mr-8">
            <h2 className="text-2xl font-bold mb-3">Download Our App</h2>
            <p className="text-gray-300 mb-6">Shop on the go with our mobile app. Get exclusive app-only offers and shop with ease.</p>
            <div className="flex space-x-4">
              <a href="#" className="bg-black px-4 py-2 rounded-lg flex items-center hover:bg-gray-900 transition-colors">
                <i className="fab fa-apple text-2xl mr-2"></i>
                <div>
                  <p className="text-xs text-gray-400">Download on the</p>
                  <p className="font-medium">App Store</p>
                </div>
              </a>
              <a href="#" className="bg-black px-4 py-2 rounded-lg flex items-center hover:bg-gray-900 transition-colors">
                <i className="fab fa-google-play text-2xl mr-2"></i>
                <div>
                  <p className="text-xs text-gray-400">GET IT ON</p>
                  <p className="font-medium">Google Play</p>
                </div>
              </a>
            </div>
          </div>
          <div className="w-full md:w-auto">
            <img 
              src="https://images.unsplash.com/photo-1616348436168-de43ad0db179?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&h=500&q=80" 
              alt="Mobile app" 
              loading="lazy"
              className="h-64 object-cover rounded-lg shadow-lg mx-auto"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default AppPromotion;
