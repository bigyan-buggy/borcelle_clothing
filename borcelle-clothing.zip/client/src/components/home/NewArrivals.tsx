import { Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Skeleton } from '@/components/ui/skeleton';
import ProductCard from '@/components/ui/product-card';
import { ArrowRight } from 'lucide-react';

interface NewArrivalsProps {
  onQuickView: (product: any) => void;
}

const NewArrivals = ({ onQuickView }: NewArrivalsProps) => {
  const { data: products, isLoading } = useQuery({
    queryKey: ['/api/products', { new: true, limit: 4 }],
    queryFn: async () => {
      const res = await fetch('/api/products?new=true&limit=4');
      if (!res.ok) throw new Error('Failed to fetch new arrivals');
      return res.json();
    }
  });

  return (
    <section className="py-12">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-semibold">New Arrivals</h2>
          <div 
            className="text-[#FF3F6C] font-medium flex items-center hover:underline cursor-pointer"
            onClick={() => window.location.href = "/products?new=true"}
          >
            View All
            <ArrowRight className="ml-2 h-4 w-4" />
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {isLoading ? (
            Array(4).fill(0).map((_, index) => (
              <div key={index}>
                <Skeleton className="w-full aspect-[3/4] rounded-md mb-3" />
                <Skeleton className="h-4 w-20 mb-2" />
                <Skeleton className="h-4 w-32 mb-2" />
                <Skeleton className="h-4 w-24" />
              </div>
            ))
          ) : (
            products?.map((product: any) => (
              <ProductCard 
                key={product.id} 
                product={product} 
                onQuickView={onQuickView}
              />
            ))
          )}
        </div>
      </div>
    </section>
  );
};

export default NewArrivals;
