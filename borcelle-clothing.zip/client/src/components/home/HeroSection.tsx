import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

const HeroSection = () => {
  return (
    <section className="relative">
      <div 
        className="w-full h-[60vh] bg-cover bg-center" 
        style={{ 
          backgroundImage: "url('https://images.unsplash.com/photo-1483985988355-763728e1935b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80')" 
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-[#282C3F]/70 to-transparent flex items-center">
          <div className="container mx-auto px-4">
            <div className="max-w-md text-white">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">Style Redefined</h1>
              <p className="text-lg mb-8">Discover the latest fashion trends and elevate your style this season.</p>
              <Link href="/products">
                <Button className="px-8 py-3 bg-[#FF3F6C] hover:bg-[#FF3F6C]/90 text-white font-medium rounded-md transition-colors">
                  Shop Now
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
