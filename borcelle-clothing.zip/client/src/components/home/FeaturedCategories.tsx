import { Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Skeleton } from '@/components/ui/skeleton';

const FeaturedCategories = () => {
  const { data: categories, isLoading } = useQuery({
    queryKey: ['/api/categories'],
    queryFn: async () => {
      const res = await fetch('/api/categories');
      if (!res.ok) throw new Error('Failed to fetch categories');
      return res.json();
    }
  });

  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-semibold mb-8 text-center">Shop By Category</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {isLoading ? (
            Array(4).fill(0).map((_, index) => (
              <div key={index}>
                <Skeleton className="w-full h-64 rounded-lg mb-3" />
                <Skeleton className="h-5 w-24 mb-2" />
              </div>
            ))
          ) : (
            categories?.map((category: any) => (
              <Link 
                key={category.id} 
                href={`/products/${category.slug}`}
                className="group"
              >
                <div className="rounded-lg overflow-hidden mb-3 relative">
                  <img 
                    src={category.imageUrl} 
                    alt={category.name} 
                    className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#282C3F]/60 to-transparent flex items-end p-4">
                    <h3 className="text-white font-medium text-lg">{category.name}</h3>
                  </div>
                </div>
              </Link>
            ))
          )}
        </div>
      </div>
    </section>
  );
};

export default FeaturedCategories;
